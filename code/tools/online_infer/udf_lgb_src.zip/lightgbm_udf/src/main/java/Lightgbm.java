import org.apache.hadoop.hive.ql.exec.UDF;
import io.github.metarank.lightgbm4j.LGBMBooster;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;

public class Lightgbm extends UDF{
    public static LGBMBooster booster;
    public Lightgbm() {
    }

    private static synchronized void init(String model_name) throws Exception {
        System.out.println("Loading model file " + model_name);
        String modelPath = extractModelFile(model_name, "model.txt").getPath();
        booster = LGBMBooster.createFromModelfile(modelPath);
    }

    private static File extractModelFile(String path, String name) throws Exception {
        Path dir = Files.createTempDirectory("model");
        File tempFile = new File(dir.toString() + "/" + name);
        System.out.println("Loading model file " + tempFile);
        InputStream modelStream = new FileInputStream(new File(path));
        OutputStream fileStream = new FileOutputStream(tempFile);
        copyStream(modelStream, fileStream);
        modelStream.close();
        fileStream.close();
        return tempFile;
    }

    private static void copyStream(InputStream source, OutputStream target) throws Exception {
        byte[] buf = new byte[8192];

        int length;
        int bytesCopied;
        for(bytesCopied = 0; (length = source.read(buf)) > 0; bytesCopied += length) {
            target.write(buf, 0, length);
        }

        System.out.println("Copied " + bytesCopied + " bytes");
    }

    public double evaluate(String fea_string, String model_name) throws Exception {
        String[] fea_list_str = fea_string.split(",");
        double[] fea_list = new double[fea_list_str.length];

        for(int i = 0; i < fea_list.length; ++i) {
            fea_list_str[i] = fea_list_str[i] != null && !fea_list_str[i].equals("") ? fea_list_str[i] : "0.0";
            fea_list[i] = Double.valueOf(fea_list_str[i]);
        }

        if (booster == null) {
            init(model_name);
        }

        double res = booster.predictForMatSingleRow(fea_list);
//        booster.close();
        return res;
    }
}
