# -*- coding: utf-8 -*-
"""
Created on Wed Jul 3 18:30:00 2024

@author: jarretthan
"""

import tensorflow as tf


def minMax(val, params):
    mode, min_val, max_val = params.strip().split('_')
    min_val, max_val = float(min_val), float(max_val)
    val = tf.cast(val, tf.float32)

    flag = tf.less(val, 0)
    flag = tf.cast(flag, tf.float32)
    # normalize = tf.clip_by_value(val, min_val, max_val)

    if "min" in mode:
        normalize = (val - min_val) / (max_val - min_val)
    elif "log" in mode:
        normalize = tf.math.log(val + 1.000001) / tf.math.log(float(max_val))
    elif "robust" in mode:
        # x_=(x-mid(x))/iqr
        # 该缩放方法下面 mid 和iqr 分别对应 min_val 和 max_val
        normalize = (val - min_val) / (max_val)
    numeric = tf.multiply(flag, -1.0) + tf.multiply((1 - flag), normalize)
    return numeric
