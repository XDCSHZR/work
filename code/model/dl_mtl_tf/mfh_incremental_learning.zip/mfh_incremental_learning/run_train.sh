#! /bin/bash
# -*- coding: utf-8 -*-
source /etc/profile
export HADOOP_USER_NAME='prod_jinrongshiyebu_international'
export HADOOP_USER_PASSWORD='Xjqj9ZSEBUJJ3FM39h42wu5I4tKEN7pw'

/home/odin/miniforge/bin/python3 dchat.py 0 '每周定时增量训练启动！'
echo 'incremental training start!'

# 轮询检查数据
/home/odin/miniforge/bin/python3 dchat.py 0 '数据检查中...'
echo 'check for tables...'

date_train=$(date -d 'last monday -2 week' '+%Y%m%d')  # 周一调度则使用 monday
date_oot=$(date -d 'last monday -1 week' '+%Y%m%d')
#date_train='20240708'
#date_oot='20240715'
echo 'train date '$date_train
echo 'oot date '$date_oot

wait_nums=48
i=1
flag=0
while [ $i -le $wait_nums ]
do
  hadoop fs -test -e hdfs://DClusterUS1/user/prod_jinrongshiyebu_international/jinrongshiyebu_international/growth_algorithm/jarretthan/offline_incremental_training/mx_cash_loan/data/sample_label_feature_${date_train}/_SUCCESS
  is_data_train=$?
  hadoop fs -test -e hdfs://DClusterUS1/user/prod_jinrongshiyebu_international/jinrongshiyebu_international/growth_algorithm/jarretthan/offline_incremental_training/mx_cash_loan/data/sample_label_feature_this_week_${date_oot}/_SUCCESS
  is_data_oot=$?
  if [ $is_data_train -eq 0 ] && [ $is_data_oot -eq 0 ]; then
    /home/odin/miniforge/bin/python3 dchat.py 0 '数据检查完成，数据正常！'
    echo 'tables exists!'
    flag=1
    break
  else
    echo 'wait for tables, time: '$i
    if [ $i -eq 25 ]; then
      /home/odin/miniforge/bin/python3 dchat.py 0 '数据检查时间超过12h（24h）！！！'
      echo 'tables check pass 12h (24h) !!!'
    fi
    let i++
    sleep 30m
  fi
done

if [ $flag -eq 0 ]; then
  /home/odin/miniforge/bin/python3 dchat.py 1 '数据检查失败！！！'
  echo 'tables check fail!!!'
  exit 1
fi

# 数据下载到本地
/home/odin/miniforge/bin/python3 dchat.py 0 '数据下载中...'
echo 'download tables...'

hadoop fs -get hdfs://DClusterUS1/user/prod_jinrongshiyebu_international/jinrongshiyebu_international/growth_algorithm/jarretthan/offline_incremental_training/mx_cash_loan/data/sample_label_feature_${date_train} ./data/
hadoop fs -get hdfs://DClusterUS1/user/prod_jinrongshiyebu_international/jinrongshiyebu_international/growth_algorithm/jarretthan/offline_incremental_training/mx_cash_loan/data/sample_label_feature_this_week_${date_oot} ./data/

# old best 模型 infer oot
/home/odin/miniforge/bin/python3 dchat.py 0 '旧模型（历史最好）'$date_oot'（当周label）推理中...'
echo 'old best model infer...'

/home/odin/miniforge/bin/python3 pred_best.py --test_data_path './data/sample_label_feature_this_week_'${date_oot}'/part-r-*' --pred_path './data/pred_res/'${date_oot}'_old.csv'
is_pred_old=$?
#is_pred_old=0
if [ $is_pred_old -eq 0 ]; then
  /home/odin/miniforge/bin/python3 dchat.py 0 '旧模型推理成功！'
  echo 'old best model infer success!'
else
  /home/odin/miniforge/bin/python3 dchat.py 1 '旧模型推理失败！！！'
  echo 'old best model infer fail!!!'
  exit 1
fi

# 模型增量train
/home/odin/miniforge/bin/python3 dchat.py 0 $date_train'模型增量训练中...'
echo 'model incremental training...'

/home/odin/miniforge/bin/python3 train.py --train_data_path './data/sample_label_feature_'${date_train}'/part-r-*' --eval_data_path './data/sample_label_feature_'${date_train}'/part-r-00000' > ./train_log/train_log_${date_train}.log 2>&1
is_train_new=$?
#is_train_new=0
if [ $is_train_new -eq 0 ]; then
  /home/odin/miniforge/bin/python3 dchat.py 0 '模型增量训练成功！'
  echo 'model incremental training success!'
else
  /home/odin/miniforge/bin/python3 dchat.py 1 '模型增量训练失败！！！'
  echo 'model incremental training fail!!!'
  exit 1
fi

# 模型增量训练结果保存
ckpt=`cat ./tf_log/mfh_aitm_sf_12_20231002/checkpoint | grep 'model_checkpoint_path:' |cut -b 36-`

/home/odin/miniforge/bin/python3 dchat.py 0 $date_train'模型增量训练结果（ckpt）'${ckpt:0:-1}'保存中...'
echo 'model incremental training result (ckpt) save...'

zip -r tf_log_mfh_aitm_sf_12_20231002_${date_train}_ckpt_${ckpt:0:-1}.zip ./tf_log/mfh_aitm_sf_12_20231002/

hadoop fs -put tf_log_mfh_aitm_sf_12_20231002_${date_train}_ckpt_${ckpt:0:-1}.zip hdfs://DClusterUS1/user/prod_jinrongshiyebu_international/jinrongshiyebu_international/growth_algorithm/jarretthan/offline_incremental_training/mx_cash_loan/model_inc_ckpt/

# new 增量训练模型 infer oot
/home/odin/miniforge/bin/python3 dchat.py 0 '新模型（'$date_train'增量训练）'$date_oot'（当周label）推理中...'
echo 'new incremental training model infer...'

/home/odin/miniforge/bin/python3 pred.py --test_data_path './data/sample_label_feature_this_week_'${date_oot}'/part-r-*' --pred_path './data/pred_res/'${date_oot}'_new.csv'
is_pred_new=$?
#is_pred_new=0
if [ $is_pred_new -eq 0 ]; then
  /home/odin/miniforge/bin/python3 dchat.py 0 '新模型推理成功！'
  echo 'new incremental training model infer success!'
else
  /home/odin/miniforge/bin/python3 dchat.py 1 '新模型推理失败！！！'
  echo 'new incremental training model infer fail!!!'
  exit 1
fi

# auc验证
/home/odin/miniforge/bin/python3 dchat.py 0 'auc验证中...'
echo 'auc calculate...'

/home/odin/miniforge/bin/python3 auc.py './data/pred_res/'${date_oot}'_old.csv' '20231002' 'mfh_aitm_sf_12_20231002_old' './data/pred_res/auc_'${date_oot}'.csv'
is_auc_old=$?
/home/odin/miniforge/bin/python3 auc.py './data/pred_res/'${date_oot}'_new.csv' '20231002' 'mfh_aitm_sf_12_20231002_new' './data/pred_res/auc_'${date_oot}'.csv'
is_auc_new=$?
if [ $is_auc_old -eq 0 ] && [ $is_auc_new -eq 0 ]; then
  /home/odin/miniforge/bin/python3 dchat.py 0 'auc验证完成！'
  echo 'auc calculate success!'
else
  /home/odin/miniforge/bin/python3 dchat.py 1 'auc验证失败！！！'
  echo 'auc calculate fail!!!'
  exit 1
fi

hadoop fs -put ./data/pred_res/auc_${date_oot}.csv hdfs://DClusterUS1/user/prod_jinrongshiyebu_international/jinrongshiyebu_international/growth_algorithm/jarretthan/offline_incremental_training/mx_cash_loan/auc/

# 模型更新
echo 'model compare...'

res_model_compare=`/home/odin/miniforge/bin/python3 auc_compare.py './data/pred_res/auc_'${date_oot}'.csv'`
echo 'model compare res: '$res_model_compare

model_name=`cat ./train_log/train_log_${date_train}.log | grep -m 1 model_save/mfh_aitm_sf_12_20231002/temp-`
model_name=`echo $model_name | awk -F ''/'' '{print $4}'`
model_name=`echo $model_name | awk -F ''-'' '{print $2}'`
echo 'model name: '$model_name

/home/odin/miniforge/bin/python3 dchat.py 0 '模型增量训练结果（pb）'$model_name'保存中...'
echo 'model incremental training result (pb) save...'

hadoop fs -put ./model_save/mfh_aitm_sf_12_20231002/$model_name hdfs://DClusterUS1/user/prod_jinrongshiyebu_international/jinrongshiyebu_international/growth_algorithm/jarretthan/offline_incremental_training/mx_cash_loan/model/

if [ $res_model_compare == 'new' ]; then
  /home/odin/miniforge/bin/python3 dchat.py 0 '使用新模型！模型更新中...'
  echo 'use new model! model update...'
  hadoop fs -mv hdfs://DClusterUS1/user/prod_jinrongshiyebu_international/jinrongshiyebu_international/growth_algorithm/jarretthan/offline_incremental_training/mx_cash_loan/model/best hdfs://DClusterUS1/user/prod_jinrongshiyebu_international/jinrongshiyebu_international/growth_algorithm/jarretthan/offline_incremental_training/mx_cash_loan/model/old/best_${date_train}
  hadoop fs -mv hdfs://DClusterUS1/user/prod_jinrongshiyebu_international/jinrongshiyebu_international/growth_algorithm/jarretthan/offline_incremental_training/mx_cash_loan/model/$model_name hdfs://DClusterUS1/user/prod_jinrongshiyebu_international/jinrongshiyebu_international/growth_algorithm/jarretthan/offline_incremental_training/mx_cash_loan/model/best
  echo ${date_train}_${model_name} >> model.log
  rm -rf ./tf_log/mfh_aitm_sf_12_20231002_best/
  cp -r ./tf_log/mfh_aitm_sf_12_20231002/ ./tf_log/mfh_aitm_sf_12_20231002_best/
else
  /home/odin/miniforge/bin/python3 dchat.py 0 '使用旧模型！模型暂不更新！'
  echo 'use old model! model update stop!'
fi

/home/odin/miniforge/bin/python3 dchat.py 0 '每周定时增量训练结束！'
echo 'incremental training end!'
