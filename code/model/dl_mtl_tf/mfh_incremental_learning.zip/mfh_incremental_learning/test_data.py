# -*- coding: utf-8 -*-
"""
Created on Fri Jun 28 11:10:00 2024

@author: jarretthan
"""

import numpy as np
import tensorflow as tf
import pickle

from PreProcess import PreProcess
from Reader import Reader
from conf_args import Configuration_argsparse
from layer.DCN import DCN
from layer.DNN import DNN
from layer.CGC import CGC
from layer.AIT import Attention, Info
from layer.Prediction import Prediction

if __name__ == '__main__':
    conf_args = Configuration_argsparse()

    pkl = open(conf_args.conf.Feature.pkl, 'rb')
    feature_map = pickle.load(pkl)
    pkl.close()

    preprocessor = PreProcess(feature_map, conf_args.conf.Seed)
    reader = Reader(columns=preprocessor.columns)

    files = tf.data.Dataset.list_files([
        conf_args.args.train_data_path, conf_args.args.eval_data_path], shuffle=True)
    examples = tf.data.TFRecordDataset(files)
    cnt = 0
    for e in examples:
        # aaa = tf.io.parse_single_example(e, reader.features_parse)
        aaa = tf.io.parse_example(e, reader.features_parse)

        numeric = tf.compat.v1.feature_column.input_layer(aaa, preprocessor.columns['numeric_columns'])
        emb = tf.compat.v1.feature_column.input_layer(aaa, preprocessor.columns['emb_columns'])

        numeric_tmp = tf.concat(numeric, axis=-1)
        emb_tmp = tf.concat(emb, axis=-1)

        inputs = tf.concat([numeric_tmp, emb_tmp], axis=-1)

        if aaa['label_credit_apply'].numpy()[0] == 1:
            cnt += 1

    print('done')
