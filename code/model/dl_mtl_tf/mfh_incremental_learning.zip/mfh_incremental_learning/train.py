# -*- coding: utf-8 -*-
"""
Created on Thu Jun 20 20:58:00 2024

@author: jarretthan
"""

import numpy as np
import json
import functools
import pickle
import tensorflow as tf
import warnings
import os

from conf_args import Configuration_argsparse
from init import init_feature_conf
from Estimator import Estimator
from PreProcess import PreProcess
# from Reader import Reader
from Reader_weight import Reader

np.set_printoptions(threshold=np.inf, suppress=True, precision=4, linewidth=np.inf)

tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.INFO)

warnings.filterwarnings('ignore')


class Trainer(object):
    def __init__(self):
        self.est_run_conf = tf.estimator.RunConfig(
            model_dir=conf_args.conf.Output.tf_log,
            tf_random_seed=conf_args.conf.Seed,
            save_checkpoints_steps=conf_args.conf.Train.save_checkpoints_steps,
            log_step_count_steps=conf_args.conf.Train.log_step_count_steps
        )

        pkl = open(conf_args.conf.Feature.pkl, 'rb')
        feature_map = pickle.load(pkl)
        pkl.close()

        self.preprocessor = PreProcess(feature_map, conf_args.conf.Seed)
        self.reader = Reader(columns=self.preprocessor.columns)

    def train(self):
        estimator_ = Estimator(
            est_run_conf=self.est_run_conf,
            feature_columns=self.preprocessor.columns,
            conf={
                'model': conf_args.conf.Model,
                'train': conf_args.conf.Train,
                'eval': conf_args.conf.Eval,
                'seed': conf_args.conf.Seed
            }
        )

        estimator = estimator_.build_estimator()

        train_input_fn = functools.partial(
            self.reader.input_fn,
            conf_args.args.train_data_path,
            conf_args.conf.Train.batch_size,
            conf_args.conf.Seed,
            conf_args.conf.Train.epochs
        )
        early_stopping_hook = tf.estimator.experimental.stop_if_no_decrease_hook(  # loss decrease
            estimator,
            # 'loss_id_123_3_plus_por',  # mfh_ait
            'loss',
            conf_args.conf.Train.early_stopping_max_steps_without_decrease,
            min_steps=conf_args.conf.Train.early_stopping_min_steps,
            run_every_secs=None, run_every_steps=conf_args.conf.Train.early_stopping_run_every_steps)
        train_spec = tf.estimator.TrainSpec(
            input_fn=train_input_fn,
            max_steps=conf_args.conf.Train.train_steps,
            hooks=[early_stopping_hook]
        )

        eval_input_fn = functools.partial(
            self.reader.input_fn,
            conf_args.args.eval_data_path,
            conf_args.conf.Eval.batch_size,
            conf_args.conf.Seed,
            conf_args.conf.Eval.epochs
        )
        eval_spec = tf.estimator.EvalSpec(
            input_fn=eval_input_fn,
            steps=None,
            start_delay_secs=conf_args.conf.Eval.start_delay_secs,
            throttle_secs=conf_args.conf.Eval.throttle_secs,
            hooks=[]
        )
        tf.estimator.train_and_evaluate(estimator, train_spec, eval_spec)

        serving_input_fn = tf.estimator.export.build_parsing_serving_input_receiver_fn(self.reader.features_parse)
        estimator.export_saved_model(
            export_dir_base=conf_args.conf.Output.model_save,
            serving_input_receiver_fn=serving_input_fn
        )


def main(argv=None):
    trainer = Trainer()
    trainer.train()


if __name__ == '__main__':
    conf_args = Configuration_argsparse()
    print(conf_args.args)
    print(conf_args.conf.Feature)
    print(conf_args.conf.Train)
    print(conf_args.conf.Eval)
    print(conf_args.conf.Output)

    # 输出文件夹初始化
    if not os.path.exists(conf_args.conf.Output.tf_log):
        os.mkdir(conf_args.conf.Output.tf_log)
    if not os.path.exists(conf_args.conf.Output.model_save):
        os.mkdir(conf_args.conf.Output.model_save)

    # 随机种子
    tf.compat.v1.set_random_seed(conf_args.conf.Seed)

    # 特征初始化
    _, feature_map, features_type = init_feature_conf(conf_args.conf.Feature.txt)

    json_dic = {}
    json_dic['feature_map'] = feature_map
    file = open(conf_args.conf.Feature.json, 'w')
    json.dump(json_dic, file)

    pkl = open(conf_args.conf.Feature.pkl, 'wb')
    pickle.dump(feature_map, pkl)
    pickle.dump(features_type, pkl)
    pkl.close()

    # 模型训练
    tf.compat.v1.logging.info('----start---')
    sess = tf.compat.v1.app.run()
