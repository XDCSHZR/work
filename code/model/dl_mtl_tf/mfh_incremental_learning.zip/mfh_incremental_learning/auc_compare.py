# -*- coding: utf-8 -*-
"""
Created on Thu Aug 1 21:00:00 2024

@author: jarretthan
"""

import pandas as pd
import sys
import warnings

from utils_ import dchat


warnings.filterwarnings('ignore')

auc_file_path = sys.argv[1]


if __name__ == '__main__':
    df_auc = pd.read_csv(auc_file_path, sep='\t', encoding='utf-8')

    tol_1, tol_2, tol_3 = 0.0005, 0.001, 0
    content = ''

    model_version = list(df_auc[df_auc['domain_id'] == 1]['model_version'])
    content += 'auc: {} - {}'.format(model_version[0], model_version[1])

    auc_1_old = df_auc[(df_auc['model_version'] == model_version[0]) & (df_auc['domain_id'] == 1)]['auc'].values[0]
    auc_1_new = df_auc[(df_auc['model_version'] == model_version[1]) & (df_auc['domain_id'] == 1)]['auc'].values[0]
    content += '\nsms card 1: tol {}, {} - {}'.format(tol_1, auc_1_old, auc_1_new)

    auc_2_old = df_auc[(df_auc['model_version'] == model_version[0]) & (df_auc['domain_id'] == 2)]['auc'].values[0]
    auc_2_new = df_auc[(df_auc['model_version'] == model_version[1]) & (df_auc['domain_id'] == 2)]['auc'].values[0]
    content += '\nsms card 2: tol {}, {} - {}'.format(tol_2, auc_2_old, auc_2_new)

    auc_3_old = df_auc[(df_auc['model_version'] == model_version[0]) & (df_auc['domain_id'] == 3)]['auc'].values[0]
    auc_3_new = df_auc[(df_auc['model_version'] == model_version[1]) & (df_auc['domain_id'] == 3)]['auc'].values[0]
    content += '\nwa: tol {}, {} - {}'.format(tol_3, auc_3_old, auc_3_new)

    dchat(0, content)

    if auc_1_new + tol_1 >= auc_1_old and auc_2_new + tol_2 >= auc_2_old and auc_3_new + tol_3 >= auc_3_old:
        print('new')
    else:
        print('old')
