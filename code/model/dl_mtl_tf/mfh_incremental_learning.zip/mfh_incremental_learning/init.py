# -*- coding: utf-8 -*-
"""
Created on Mon Jun 25 11:30:00 2024

@author: jarretthan
"""

import io
import traceback


def get_lines(file):
    count = 0
    f = io.open(file, "r", encoding="utf-8")
    for _ in f.readlines():
        count = count + 1
    return count


def get_cross_fea_file(hex15):
    f = io.open(hex15, "r", encoding="utf-8")

    hex15TimeSlice5 = []
    hex15TimeSlice5IfWorkDay = []
    hex15driverTypeIfWorkDay = []

    for line in f.readlines():
        hex15 = line.strip()
        for timeSlice5 in range(0, 290):
            timeSlice5 = str(timeSlice5)
            cur_hex15TimeSlice5 = hex15 + "_" + timeSlice5
            hex15TimeSlice5.append(cur_hex15TimeSlice5)
            for ifWorkDay in range(0, 4):
                cur_hex15TimeSlice5IfWorkDay = hex15 + "_" + timeSlice5 + "_" + str(ifWorkDay)
                hex15TimeSlice5IfWorkDay.append(cur_hex15TimeSlice5IfWorkDay)
        for driverType in range(0, 3):
            for ifWorkDay in range(0, 4):
                cur = hex15 + "_" + str(driverType) + "_" + str(ifWorkDay)
                hex15driverTypeIfWorkDay.append(cur)

    hex15TimeSlice5_file = io.open("./map_file/hex15TimeSlice5_file", 'w', encoding="utf-8")
    hex15TimeSlice5IfWorkDay_file = io.open("./map_file/hex15TimeSlice5IfWorkDay_file", 'w', encoding="utf-8")
    hex15driverTypeIfWorkDay_file = io.open("./map_file/hex15driverTypeIfWorkDay_file", 'w', encoding="utf-8")
    sep = "\n"
    hex15TimeSlice5_file.write(sep.join(hex15TimeSlice5))
    hex15TimeSlice5IfWorkDay_file.write(sep.join(hex15TimeSlice5IfWorkDay))
    hex15driverTypeIfWorkDay_file.write(sep.join(hex15driverTypeIfWorkDay))
    print("#init_old.py# 【交叉特征文件】生成完成，路径：./map_file/ ")


def get_feature_type(data_type, process_func):
    if data_type == 'string':
        if 'fix' in process_func:
            return 'fixLength_string_feature'
        else:
            return 'string_feature'
    elif data_type == 'int':
        if 'fix' in process_func:
            return 'fixLength_int_feature'
        else:
            return 'int_feature'
    elif data_type == 'float':
        if 'fix' in process_func:
            return 'fixLength_float_feature'
        else:
            return 'float_feature'


def get_default_value(data_type, default_value):
    if default_value == '-':
        return default_value
    if data_type == 'float':
        return float(default_value)
    if data_type == 'int':
        return int(default_value)
    if data_type == 'string':
        return default_value


def init_feature_conf(file):
    features = []
    features_type = {}
    feature_map = {}
    emb_cols = []
    numeric_columns = []
    fixedLenStringFeature = []
    fixedLenFloatFeature = []
    sms_emb = []
    sms_numeric = []
    wa_emb = []
    wa_numeric = []

    with io.open(file, "r", encoding="utf-8") as open_file:
        try:
            for line in open_file:
                if (u"#" in line.strip("\n")) or (len(line.strip("\n")) == 0):
                    continue
                res = [i.strip() for i in line.strip("\n").split("|")]
                if len(res) < 9:
                    res.append('no')
                feature, process_func, inputs, params, length, \
                    emb_size, data_type, default_value, share_tag = res

                features.append(feature)
                feature_map[feature] = {}
                feature_map[feature]['process_func'] = process_func
                feature_map[feature]['input'] = inputs
                feature_map[feature]['params'] = params
                feature_map[feature]['length'] = length
                feature_map[feature]['emb_size'] = emb_size
                feature_map[feature]['dtype'] = data_type
                feature_map[feature]['default_value'] = get_default_value(data_type, default_value)
                feature_map[feature]['share_tag'] = share_tag

                if "file" in params:
                    length = get_lines("./map_test/{}".format(params))
                elif "-" not in params and length == '-':
                    length = len(list(eval(params)))
                feature_map[feature]['length'] = length

                cur_type = get_feature_type(data_type, process_func)
                if cur_type not in features_type:
                    features_type[cur_type] = set()
                features_type[cur_type].add(inputs)

                if ('bucket' in process_func or 'categorical' in process_func) and share_tag == 'no':
                    emb_cols.append(feature)
                elif ("numeric" in process_func) and share_tag == 'no':
                    numeric_columns.append(feature)
                elif ('bucket' in process_func or 'categorical' in process_func) and share_tag == 'sms':
                    sms_emb.append(feature)
                elif ("numeric" in process_func) and share_tag == 'sms':
                    sms_numeric.append(feature)
                elif ('bucket' in process_func or 'categorical' in process_func) and share_tag == 'wa':
                    wa_emb.append(feature)
                elif ("numeric" in process_func) and share_tag == 'wa':
                    wa_numeric.append(feature)

                if 'categorical_file' in process_func:  # 需要one-hot处理的特征
                    feature_map[feature]['length'] = length
                    feature_map[feature]['emb_type'] = 'file'
                    feature_map[feature]['map_file'] = params
                    feature_map[feature]['default_val'] = length
                elif 'categorical_list' in process_func:
                    feature_map[feature]['default_val'] = length
                    feature_map[feature]['emb_type'] = 'list'

                if process_func == 'fixedLenFeature' and data_type == 'string':
                    fixedLenStringFeature.append(feature)
                if process_func == 'fixedLenFeature' and data_type == 'float':
                    fixedLenFloatFeature.append(feature)

            feature_map['feature_list'] = features
            feature_map['emb_cols'] = emb_cols
            feature_map['numeric_cols'] = numeric_columns
            feature_map['fixedLenStringFeature'] = fixedLenStringFeature
            feature_map['fixedLenFloatFeature'] = fixedLenFloatFeature
            feature_map['sms_emb_cols'] = sms_emb
            feature_map['sms_numeric_cols'] = sms_numeric
            feature_map['wa_emb_cols'] = wa_emb
            feature_map['wa_numeric_cols'] = wa_numeric

        except Exception as err:
            traceback.print_exc()
            print('error!!!!', line.strip("\n").split("|"), length)
            print(err, feature)
        return features, feature_map, features_type


if __name__ == '__main__':
    pass
