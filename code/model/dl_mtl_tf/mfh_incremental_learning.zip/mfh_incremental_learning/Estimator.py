# -*- coding: utf-8 -*-
"""
Created on Fri Jun 21 17:50:00 2024

@author: jarretthan
"""

import tensorflow as tf

from model.MFH_AITM import MFH_AITM
from model.SB_DCN_old import SB_DCN_old
from model.MFH_AITM_SF import MFH_AITM_SF


class Estimator(object):
    def __init__(self, est_run_conf, feature_columns, conf):
        self.est_run_conf = est_run_conf
        self.feature_columns = feature_columns
        self.conf = conf

    def build_estimator(self):
        """
        model_fn: Model function. Follows the signature:
        Args:
            features:  是从 input_fn中返回的词典tensor 或者 单个tensor ;其实质就是模型的输入（以前我们都是用tf.placeholder输入的，这里使用input_fn 函数返回）  This is the first item returned from the input_fn
            labels:  是从 input_fn中返回的词典tensor 或者 单个tensor,注意，如果mode=tf.estimator.ModeKeys.PREDICT(就是在预测的时候), labels将会被设置为None  This is the second item returned from the input_fn
            mode: Optional. Specifies if this training, evaluation or prediction. See tf.estimator.ModeKeys.
            params: Optional dict of hyperparameters.接受初始化Estimator实例时的参数params
            config: Optional estimator.RunConfig object.接受初始化Estimator实例时的参数config  或者一个默认的值. Allows setting up things in your model_fn based on configuration such as num_ps_replicas, or model_dir.
            Returns: tf.estimator.EstimatorSpec  这里一定要注意 返回的是EstimatorSpec实例
        """

        my_estimator = tf.estimator.Estimator(
            # model_fn=self.model_fn_mfh_aitm,  # mfh_aitm
            # model_fn=self.model_fn_sb_dcn_old,  # sb_dcn_old
            # model_fn=self.model_fn_mfh_aitm_spec_feats,  # mfh_aitm sms wa
            model_fn=self.model_fn_mfh_aitm_spec_feats_weight,  # mfh_aitm sms wa weight
            config=self.est_run_conf,
            params={
                'conf': self.conf,
                'emb_columns': self.feature_columns['emb_columns'],
                'numeric_columns': self.feature_columns['numeric_columns'],
                'sms_emb': self.feature_columns['sms_emb'],
                'sms_numeric': self.feature_columns['sms_numeric'],
                'wa_emb': self.feature_columns['wa_emb'],
                'wa_numeric': self.feature_columns['wa_numeric']
            }
        )

        return my_estimator

    def model_fn_mfh_aitm(self, features, labels, mode, params):
        # 模型
        model = MFH_AITM(params['conf'])

        # input
        numeric = tf.compat.v1.feature_column.input_layer(features, params['numeric_columns'])  # tensor
        emb = tf.compat.v1.feature_column.input_layer(features, params['emb_columns'])

        # output
        y_hat = model.inference(numeric, emb, mode)  # [[y_hat_id_1_exposure,y_hat_id_1_register,y_hat_id_1_credit_apply,y_hat_id_1_credit_submit],[y_hat_id_2_exposure.],[.]], [3,4]

        # pred，放在labels处理之前，用于export_saved_model
        if mode == tf.estimator.ModeKeys.PREDICT:
            predictions = {
                'uid': features['uid'],
                'obs_dt': features['obs_dt'],
                'features_date': features['features_date'],
                'domain_id': features['domain_id'],
                'label_credit_submit': features['label_credit_submit'],
                'pred_id_1_exposure': y_hat[0][0],
                'pred_id_1_register': y_hat[0][1],
                'pred_id_1_credit_apply': y_hat[0][2],
                'pred_id_1_credit_submit': y_hat[0][3],
                'pred_id_2_exposure': y_hat[1][0],
                'pred_id_2_register': y_hat[1][1],
                'pred_id_2_credit_apply': y_hat[1][2],
                'pred_id_2_credit_submit': y_hat[1][3],
                'pred_id_3_exposure': y_hat[2][0],
                'pred_id_3_register': y_hat[2][1],
                'pred_id_3_credit_apply': y_hat[2][2],
                'pred_id_3_credit_submit': y_hat[2][3]
            }
            return tf.estimator.EstimatorSpec(mode, predictions=predictions)

        # label
        id_1, id_2, id_3 = tf.cast(labels['id_1'], tf.float32), \
                           tf.cast(labels['id_2'], tf.float32), \
                           tf.cast(labels['id_3'], tf.float32)
        label_exposure, label_register, label_credit_apply, label_credit_submit = \
            tf.cast(labels['label_exposure'], tf.float32), \
            tf.cast(labels['label_register'], tf.float32), \
            tf.cast(labels['label_credit_apply'], tf.float32), \
            tf.cast(labels['label_credit_submit'], tf.float32)

        y = [
            [id_1 * label_exposure, id_1 * label_register, id_1 * label_credit_apply, id_1 * label_credit_submit],
            [id_2 * label_exposure, id_2 * label_register, id_2 * label_credit_apply, id_2 * label_credit_submit],
            [id_3 * label_exposure, id_3 * label_register, id_3 * label_credit_apply, id_3 * label_credit_submit]
        ]  # [3,4]

        id = [id_1, id_2, id_3]  # [3]

        # loss
        loss_all, _, _, loss_credit_submit_plus_por, loss_list, loss_constraint_list, loss_all_uwl, _ \
            = model.loss_function(y_hat, y, id)

        if params['conf']['train'].use_uwl:
            loss_train = loss_all_uwl
        else:
            loss_train = loss_all

        # metric
        metrics = {
            'AUC_id_1_0': tf.compat.v1.metrics.auc(y[0][0], y_hat[0][0], num_thresholds=800),  # exposure, 精度取决于num_thresholds（依据batch_size设定）
            'AUC_id_1_1': tf.compat.v1.metrics.auc(y[0][1], y_hat[0][1], num_thresholds=800),  # register
            'AUC_id_1_2': tf.compat.v1.metrics.auc(y[0][2], y_hat[0][2], num_thresholds=800),  # credit_apply
            'AUC_id_1_3': tf.compat.v1.metrics.auc(y[0][3], y_hat[0][3], num_thresholds=800),  # credit_submit
            'AUC_id_2_0': tf.compat.v1.metrics.auc(y[1][0], y_hat[1][0], num_thresholds=800),
            'AUC_id_2_1': tf.compat.v1.metrics.auc(y[1][1], y_hat[1][1], num_thresholds=800),
            'AUC_id_2_2': tf.compat.v1.metrics.auc(y[1][2], y_hat[1][2], num_thresholds=800),
            'AUC_id_2_3': tf.compat.v1.metrics.auc(y[1][3], y_hat[1][3], num_thresholds=800),
            'AUC_id_3_0': tf.compat.v1.metrics.auc(y[2][0], y_hat[2][0], num_thresholds=800),
            'AUC_id_3_1': tf.compat.v1.metrics.auc(y[2][1], y_hat[2][1], num_thresholds=800),
            'AUC_id_3_2': tf.compat.v1.metrics.auc(y[2][2], y_hat[2][2], num_thresholds=800),
            'AUC_id_3_3': tf.compat.v1.metrics.auc(y[2][3], y_hat[2][3], num_thresholds=800),
            'loss_id_123_3_plus_por': tf.compat.v1.metrics.mean(loss_credit_submit_plus_por),  # early stopping
            'loss_id_1_0': tf.compat.v1.metrics.mean(loss_list[0][0]),
            'loss_id_1_1': tf.compat.v1.metrics.mean(loss_list[0][1]),
            'loss_id_1_2': tf.compat.v1.metrics.mean(loss_list[0][2]),
            'loss_id_1_3': tf.compat.v1.metrics.mean(loss_list[0][3]),
            'loss_id_2_0': tf.compat.v1.metrics.mean(loss_list[1][0]),
            'loss_id_2_1': tf.compat.v1.metrics.mean(loss_list[1][1]),
            'loss_id_2_2': tf.compat.v1.metrics.mean(loss_list[1][2]),
            'loss_id_2_3': tf.compat.v1.metrics.mean(loss_list[1][3]),
            'loss_id_3_0': tf.compat.v1.metrics.mean(loss_list[2][0]),
            'loss_id_3_1': tf.compat.v1.metrics.mean(loss_list[2][1]),
            'loss_id_3_2': tf.compat.v1.metrics.mean(loss_list[2][2]),
            'loss_id_3_3': tf.compat.v1.metrics.mean(loss_list[2][3]),
            'loss_por_id_1_01': tf.compat.v1.metrics.mean(loss_constraint_list[0][0]),
            'loss_por_id_1_12': tf.compat.v1.metrics.mean(loss_constraint_list[0][1]),
            'loss_por_id_1_23': tf.compat.v1.metrics.mean(loss_constraint_list[0][2]),
            'loss_por_id_2_01': tf.compat.v1.metrics.mean(loss_constraint_list[1][0]),
            'loss_por_id_2_12': tf.compat.v1.metrics.mean(loss_constraint_list[1][1]),
            'loss_por_id_2_23': tf.compat.v1.metrics.mean(loss_constraint_list[1][2]),
            'loss_por_id_3_01': tf.compat.v1.metrics.mean(loss_constraint_list[2][0]),
            'loss_por_id_3_12': tf.compat.v1.metrics.mean(loss_constraint_list[2][1]),
            'loss_por_id_3_23': tf.compat.v1.metrics.mean(loss_constraint_list[2][2])
        }

        # log
        id_1_num = tf.reduce_sum(id[0])
        id_1_credit_submit_num = tf.reduce_sum(y[0][3])
        id_1_cvr = id_1_credit_submit_num / id_1_num
        id_1_pcvr = tf.reduce_mean(y_hat[0][3])
        id_2_num = tf.reduce_sum(id[1])
        id_2_credit_submit_num = tf.reduce_sum(y[1][3])
        id_2_cvr = id_2_credit_submit_num / id_2_num
        id_2_pcvr = tf.reduce_mean(y_hat[1][3])
        id_3_num = tf.reduce_sum(id[2])
        id_3_credit_submit_num = tf.reduce_sum(y[2][3])
        id_3_cvr = id_3_credit_submit_num / id_3_num
        id_3_pcvr = tf.reduce_mean(y_hat[2][3])
        logging_info = {
            'id_1_num': id_1_num, 'id_1_credit_submit_num': id_1_credit_submit_num, 'id_1_cvr': id_1_cvr,
            'id_1_pcvr': id_1_pcvr, 'id_1_pcoc': id_1_pcvr/id_1_cvr,
            'id_2_num': id_2_num, 'id_2_credit_submit_num': id_2_credit_submit_num, 'id_2_cvr': id_2_cvr,
            'id_2_pcvr': id_2_pcvr, 'id_2_pcoc': id_2_pcvr/id_2_cvr,
            'id_3_num': id_3_num, 'id_3_credit_submit_num': id_3_credit_submit_num, 'id_3_cvr': id_3_cvr,
            'id_3_pcvr': id_3_pcvr, 'id_3_pcoc': id_3_pcvr/id_3_cvr
        }
        logging_hook = tf.compat.v1.train.LoggingTensorHook(
            logging_info, every_n_iter=params['conf']['eval'].logging_hook_steps)

        if mode == tf.estimator.ModeKeys.EVAL:
            return tf.estimator.EstimatorSpec(
                mode, loss=loss_train, eval_metric_ops=metrics, evaluation_hooks=[logging_hook])

        assert mode == tf.estimator.ModeKeys.TRAIN
        train_op, lr = model.train_function(loss_train)
        logging_hook_ = tf.compat.v1.train.LoggingTensorHook(
            {**logging_info, 'lr': lr}, every_n_iter=params['conf']['train'].logging_hook_steps)

        return tf.estimator.EstimatorSpec(mode, loss=loss_train, train_op=train_op, eval_metric_ops=metrics,
                                          training_hooks=[logging_hook_], evaluation_hooks=[logging_hook])

    def model_fn_sb_dcn_old(self, features, labels, mode, params):
        # 模型
        model = SB_DCN_old()

        # input
        numeric = tf.compat.v1.feature_column.input_layer(features, params['numeric_columns'])  # tensor
        emb = tf.compat.v1.feature_column.input_layer(features, params['emb_columns'])
        # emb = tf.compat.v1.Print(emb, [emb], message="emb:", summarize=100)

        # output
        id_1, id_2, id_3 = tf.cast(features['id_1'], tf.float32), \
                           tf.cast(features['id_2'], tf.float32), \
                           tf.cast(features['id_3'], tf.float32)
        y_hat_1, y_hat_2, y_hat_3 = model.inference(numeric, emb, mode, id_1, id_2, id_3)

        # pred，放在labels处理之前，用于export_saved_model
        if mode == tf.estimator.ModeKeys.PREDICT:
            predictions = {
                'uid': features['uid'],
                'obs_dt': features['obs_dt'],
                'features_date': features['features_date'],
                'domain_id': features['domain_id'],
                'label_credit_submit': features['label_credit_submit'],
                'pred_id_1_credit_submit': y_hat_1,
                'pred_id_2_credit_submit': y_hat_2,
                'pred_id_3_credit_submit': y_hat_3
            }
            return tf.estimator.EstimatorSpec(mode, predictions=predictions)

        # label
        label_credit_submit = tf.cast(labels['label_credit_submit'], tf.float32)

        y_1, y_2, y_3 = id_1 * label_credit_submit, id_2 * label_credit_submit, id_3 * label_credit_submit

        # loss
        loss = model.loss_function(y_hat_1, y_hat_2, y_hat_3, y_1, y_2, y_3)

        # metric
        metrics = {
            'AUC_id_1': tf.compat.v1.metrics.auc(y_1, y_hat_1, num_thresholds=800),
            'AUC_id_2': tf.compat.v1.metrics.auc(y_2, y_hat_2, num_thresholds=800),
            'AUC_id_3': tf.compat.v1.metrics.auc(y_3, y_hat_3, num_thresholds=800)
        }

        # log
        id_1_num = tf.reduce_sum(id_1)
        id_1_credit_submit_num = tf.reduce_sum(y_1)
        id_1_cvr = id_1_credit_submit_num / id_1_num
        id_1_pcvr = tf.reduce_mean(y_hat_1)
        id_2_num = tf.reduce_sum(id_2)
        id_2_credit_submit_num = tf.reduce_sum(y_2)
        id_2_cvr = id_2_credit_submit_num / id_2_num
        id_2_pcvr = tf.reduce_mean(y_hat_2)
        id_3_num = tf.reduce_sum(id_3)
        id_3_credit_submit_num = tf.reduce_sum(y_3)
        id_3_cvr = id_3_credit_submit_num / id_3_num
        id_3_pcvr = tf.reduce_mean(y_hat_3)
        logging_info = {
            'id_1_num': id_1_num, 'id_1_credit_submit_num': id_1_credit_submit_num, 'id_1_cvr': id_1_cvr,
            'id_1_pcvr': id_1_pcvr, 'id_1_pcoc': id_1_pcvr/id_1_cvr,
            'id_2_num': id_2_num, 'id_2_credit_submit_num': id_2_credit_submit_num, 'id_2_cvr': id_2_cvr,
            'id_2_pcvr': id_2_pcvr, 'id_2_pcoc': id_2_pcvr/id_2_cvr,
            'id_3_num': id_3_num, 'id_3_credit_submit_num': id_3_credit_submit_num, 'id_3_cvr': id_3_cvr,
            'id_3_pcvr': id_3_pcvr, 'id_3_pcoc': id_3_pcvr/id_3_cvr
        }
        logging_hook = tf.compat.v1.train.LoggingTensorHook(
            logging_info, every_n_iter=params['conf']['eval'].logging_hook_steps)

        if mode == tf.estimator.ModeKeys.EVAL:
            return tf.estimator.EstimatorSpec(
                mode, loss=loss, eval_metric_ops=metrics, evaluation_hooks=[logging_hook])

        assert mode == tf.estimator.ModeKeys.TRAIN
        train_op = model.train_function(loss)
        logging_hook_ = tf.compat.v1.train.LoggingTensorHook(
            logging_info, every_n_iter=params['conf']['train'].logging_hook_steps)

        return tf.estimator.EstimatorSpec(mode, loss=loss, train_op=train_op, eval_metric_ops=metrics,
                                          training_hooks=[logging_hook_], evaluation_hooks=[logging_hook])

    def model_fn_mfh_aitm_spec_feats(self, features, labels, mode, params):
        # 模型
        model = MFH_AITM_SF(params['conf'])

        # input
        numeric = tf.compat.v1.feature_column.input_layer(features, params['numeric_columns'])  # tensor
        emb = tf.compat.v1.feature_column.input_layer(features, params['emb_columns'])
        emb_sms = tf.compat.v1.feature_column.input_layer(features, params['sms_emb'])
        emb_wa = tf.compat.v1.feature_column.input_layer(features, params['wa_emb'])

        # output
        y_hat = model.inference(numeric, emb, emb_sms, emb_wa, mode)  # [[y_hat_id_1_exposure,y_hat_id_1_register,y_hat_id_1_credit_apply,y_hat_id_1_credit_submit],[y_hat_id_2_exposure.],[.]], [3,4]

        # pred，放在labels处理之前，用于export_saved_model
        if mode == tf.estimator.ModeKeys.PREDICT:
            predictions = {
                'uid': features['uid'],
                'obs_dt': features['obs_dt'],
                'features_date': features['features_date'],
                'domain_id': features['domain_id'],
                'label_credit_submit': features['label_credit_submit'],
                'pred_id_1_exposure': y_hat[0][0],
                'pred_id_1_register': y_hat[0][1],
                'pred_id_1_credit_apply': y_hat[0][2],
                'pred_id_1_credit_submit': y_hat[0][3],
                'pred_id_2_exposure': y_hat[1][0],
                'pred_id_2_register': y_hat[1][1],
                'pred_id_2_credit_apply': y_hat[1][2],
                'pred_id_2_credit_submit': y_hat[1][3],
                'pred_id_3_exposure': y_hat[2][0],
                'pred_id_3_register': y_hat[2][1],
                'pred_id_3_credit_apply': y_hat[2][2],
                'pred_id_3_credit_submit': y_hat[2][3]
            }
            return tf.estimator.EstimatorSpec(mode, predictions=predictions)

        # label
        id_1, id_2, id_3 = tf.cast(labels['id_1'], tf.float32), \
                           tf.cast(labels['id_2'], tf.float32), \
                           tf.cast(labels['id_3'], tf.float32)
        label_exposure, label_register, label_credit_apply, label_credit_submit = \
            tf.cast(labels['label_exposure'], tf.float32), \
            tf.cast(labels['label_register'], tf.float32), \
            tf.cast(labels['label_credit_apply'], tf.float32), \
            tf.cast(labels['label_credit_submit'], tf.float32)

        y = [
            [id_1 * label_exposure, id_1 * label_register, id_1 * label_credit_apply, id_1 * label_credit_submit],
            [id_2 * label_exposure, id_2 * label_register, id_2 * label_credit_apply, id_2 * label_credit_submit],
            [id_3 * label_exposure, id_3 * label_register, id_3 * label_credit_apply, id_3 * label_credit_submit]
        ]  # [3,4]

        id = [id_1, id_2, id_3]  # [3]

        # loss
        loss_all, _, _, loss_credit_submit_plus_por, loss_list, loss_constraint_list, loss_all_uwl, _ \
            = model.loss_function(y_hat, y, id)

        if params['conf']['train'].use_uwl:
            loss_train = loss_all_uwl
        else:
            loss_train = loss_all

        # metric
        metrics = {
            'loss_id_123_3_plus_por': tf.compat.v1.metrics.mean(loss_credit_submit_plus_por),  # early stopping
            'loss_id_1_0': tf.compat.v1.metrics.mean(loss_list[0][0]),
            'loss_id_1_1': tf.compat.v1.metrics.mean(loss_list[0][1]),
            'loss_id_1_2': tf.compat.v1.metrics.mean(loss_list[0][2]),
            'loss_id_1_3': tf.compat.v1.metrics.mean(loss_list[0][3]),
            'loss_id_2_0': tf.compat.v1.metrics.mean(loss_list[1][0]),
            'loss_id_2_1': tf.compat.v1.metrics.mean(loss_list[1][1]),
            'loss_id_2_2': tf.compat.v1.metrics.mean(loss_list[1][2]),
            'loss_id_2_3': tf.compat.v1.metrics.mean(loss_list[1][3]),
            'loss_id_3_0': tf.compat.v1.metrics.mean(loss_list[2][0]),
            'loss_id_3_1': tf.compat.v1.metrics.mean(loss_list[2][1]),
            'loss_id_3_2': tf.compat.v1.metrics.mean(loss_list[2][2]),
            'loss_id_3_3': tf.compat.v1.metrics.mean(loss_list[2][3]),
            'loss_por_id_1_01': tf.compat.v1.metrics.mean(loss_constraint_list[0][0]),
            'loss_por_id_1_12': tf.compat.v1.metrics.mean(loss_constraint_list[0][1]),
            'loss_por_id_1_23': tf.compat.v1.metrics.mean(loss_constraint_list[0][2]),
            'loss_por_id_2_01': tf.compat.v1.metrics.mean(loss_constraint_list[1][0]),
            'loss_por_id_2_12': tf.compat.v1.metrics.mean(loss_constraint_list[1][1]),
            'loss_por_id_2_23': tf.compat.v1.metrics.mean(loss_constraint_list[1][2]),
            'loss_por_id_3_01': tf.compat.v1.metrics.mean(loss_constraint_list[2][0]),
            'loss_por_id_3_12': tf.compat.v1.metrics.mean(loss_constraint_list[2][1]),
            'loss_por_id_3_23': tf.compat.v1.metrics.mean(loss_constraint_list[2][2])
        }

        # log
        id_1_num = tf.reduce_sum(id[0])
        id_1_credit_submit_num = tf.reduce_sum(y[0][3])
        id_1_cvr = id_1_credit_submit_num / id_1_num
        id_1_pcvr = tf.reduce_mean(y_hat[0][3])
        id_2_num = tf.reduce_sum(id[1])
        id_2_credit_submit_num = tf.reduce_sum(y[1][3])
        id_2_cvr = id_2_credit_submit_num / id_2_num
        id_2_pcvr = tf.reduce_mean(y_hat[1][3])
        id_3_num = tf.reduce_sum(id[2])
        id_3_credit_submit_num = tf.reduce_sum(y[2][3])
        id_3_cvr = id_3_credit_submit_num / id_3_num
        id_3_pcvr = tf.reduce_mean(y_hat[2][3])
        logging_info = {
            'id_1_num': id_1_num, 'id_1_credit_submit_num': id_1_credit_submit_num, 'id_1_cvr': id_1_cvr,
            'id_1_pcvr': id_1_pcvr, 'id_1_pcoc': id_1_pcvr/id_1_cvr,
            'id_2_num': id_2_num, 'id_2_credit_submit_num': id_2_credit_submit_num, 'id_2_cvr': id_2_cvr,
            'id_2_pcvr': id_2_pcvr, 'id_2_pcoc': id_2_pcvr/id_2_cvr,
            'id_3_num': id_3_num, 'id_3_credit_submit_num': id_3_credit_submit_num, 'id_3_cvr': id_3_cvr,
            'id_3_pcvr': id_3_pcvr, 'id_3_pcoc': id_3_pcvr/id_3_cvr
        }
        logging_hook = tf.compat.v1.train.LoggingTensorHook(
            logging_info, every_n_iter=params['conf']['eval'].logging_hook_steps)

        if mode == tf.estimator.ModeKeys.EVAL:
            return tf.estimator.EstimatorSpec(
                mode, loss=loss_train, eval_metric_ops=metrics, evaluation_hooks=[logging_hook])

        assert mode == tf.estimator.ModeKeys.TRAIN
        train_op, lr = model.train_function(loss_train)
        logging_hook_ = tf.compat.v1.train.LoggingTensorHook(
            {**logging_info, 'lr': lr}, every_n_iter=params['conf']['train'].logging_hook_steps)

        return tf.estimator.EstimatorSpec(mode, loss=loss_train, train_op=train_op, eval_metric_ops=metrics,
                                          training_hooks=[logging_hook_], evaluation_hooks=[logging_hook])

    def model_fn_mfh_aitm_spec_feats_weight(self, features, labels, mode, params):
        # 模型
        model = MFH_AITM_SF(params['conf'])

        # input
        numeric = tf.compat.v1.feature_column.input_layer(features, params['numeric_columns'])  # tensor
        emb = tf.compat.v1.feature_column.input_layer(features, params['emb_columns'])
        emb_sms = tf.compat.v1.feature_column.input_layer(features, params['sms_emb'])
        emb_wa = tf.compat.v1.feature_column.input_layer(features, params['wa_emb'])

        # output
        y_hat = model.inference(numeric, emb, emb_sms, emb_wa, mode)  # [[y_hat_id_1_exposure,y_hat_id_1_register,y_hat_id_1_credit_apply,y_hat_id_1_credit_submit],[y_hat_id_2_exposure.],[.]], [3,4]

        # pred，放在labels处理之前，用于export_saved_model
        if mode == tf.estimator.ModeKeys.PREDICT:
            predictions = {
                'uid': features['uid'],
                'obs_dt': features['obs_dt'],
                'features_date': features['features_date'],
                'domain_id': features['domain_id'],
                'sample_weight': features['sample_weight'],
                'label_credit_submit': features['label_credit_submit'],
                'pred_id_1_exposure': y_hat[0][0],
                'pred_id_1_register': y_hat[0][1],
                'pred_id_1_credit_apply': y_hat[0][2],
                'pred_id_1_credit_submit': y_hat[0][3],
                'pred_id_2_exposure': y_hat[1][0],
                'pred_id_2_register': y_hat[1][1],
                'pred_id_2_credit_apply': y_hat[1][2],
                'pred_id_2_credit_submit': y_hat[1][3],
                'pred_id_3_exposure': y_hat[2][0],
                'pred_id_3_register': y_hat[2][1],
                'pred_id_3_credit_apply': y_hat[2][2],
                'pred_id_3_credit_submit': y_hat[2][3]
            }
            return tf.estimator.EstimatorSpec(mode, predictions=predictions)

        # label
        id_1, id_2, id_3 = tf.cast(labels['id_1'], tf.float32), \
                           tf.cast(labels['id_2'], tf.float32), \
                           tf.cast(labels['id_3'], tf.float32)
        weight = tf.cast(labels['sample_weight'], tf.float32)
        # weight = tf.compat.v1.Print(weight, [weight], message="weight:", summarize=100)
        label_exposure, label_register, label_credit_apply, label_credit_submit = \
            tf.cast(labels['label_exposure'], tf.float32), \
            tf.cast(labels['label_register'], tf.float32), \
            tf.cast(labels['label_credit_apply'], tf.float32), \
            tf.cast(labels['label_credit_submit'], tf.float32)

        y = [
            [id_1 * label_exposure, id_1 * label_register, id_1 * label_credit_apply, id_1 * label_credit_submit],
            [id_2 * label_exposure, id_2 * label_register, id_2 * label_credit_apply, id_2 * label_credit_submit],
            [id_3 * label_exposure, id_3 * label_register, id_3 * label_credit_apply, id_3 * label_credit_submit]
        ]  # [3,4]

        id = [id_1, id_2, id_3]  # [3]

        w_1 = tf.ones_like(weight) * 10
        # w_1 = tf.compat.v1.Print(w_1, [w_1], message="w_1:", summarize=100)
        w_0 = tf.ones_like(weight)
        # w_0 = tf.compat.v1.Print(w_0, [w_0], message="w_0:", summarize=100)
        w = tf.where(tf.equal(weight, tf.ones_like(weight)), w_1, w_0)
        # w = tf.compat.v1.Print(w, [w], message="w:", summarize=100)

        # loss
        loss_all, _, _, loss_credit_submit_plus_por, loss_list, loss_constraint_list, loss_all_uwl, _ \
            = model.loss_function_weight(y_hat, y, id, w)

        if params['conf']['train'].use_uwl:
            loss_train = loss_all_uwl
        else:
            loss_train = loss_all

        # metric
        metrics = {
            'loss_id_123_3_plus_por': tf.compat.v1.metrics.mean(loss_credit_submit_plus_por),  # early stopping
            'loss_id_1_0': tf.compat.v1.metrics.mean(loss_list[0][0]),
            'loss_id_1_1': tf.compat.v1.metrics.mean(loss_list[0][1]),
            'loss_id_1_2': tf.compat.v1.metrics.mean(loss_list[0][2]),
            'loss_id_1_3': tf.compat.v1.metrics.mean(loss_list[0][3]),
            'loss_id_2_0': tf.compat.v1.metrics.mean(loss_list[1][0]),
            'loss_id_2_1': tf.compat.v1.metrics.mean(loss_list[1][1]),
            'loss_id_2_2': tf.compat.v1.metrics.mean(loss_list[1][2]),
            'loss_id_2_3': tf.compat.v1.metrics.mean(loss_list[1][3]),
            'loss_id_3_0': tf.compat.v1.metrics.mean(loss_list[2][0]),
            'loss_id_3_1': tf.compat.v1.metrics.mean(loss_list[2][1]),
            'loss_id_3_2': tf.compat.v1.metrics.mean(loss_list[2][2]),
            'loss_id_3_3': tf.compat.v1.metrics.mean(loss_list[2][3]),
            'loss_por_id_1_01': tf.compat.v1.metrics.mean(loss_constraint_list[0][0]),
            'loss_por_id_1_12': tf.compat.v1.metrics.mean(loss_constraint_list[0][1]),
            'loss_por_id_1_23': tf.compat.v1.metrics.mean(loss_constraint_list[0][2]),
            'loss_por_id_2_01': tf.compat.v1.metrics.mean(loss_constraint_list[1][0]),
            'loss_por_id_2_12': tf.compat.v1.metrics.mean(loss_constraint_list[1][1]),
            'loss_por_id_2_23': tf.compat.v1.metrics.mean(loss_constraint_list[1][2]),
            'loss_por_id_3_01': tf.compat.v1.metrics.mean(loss_constraint_list[2][0]),
            'loss_por_id_3_12': tf.compat.v1.metrics.mean(loss_constraint_list[2][1]),
            'loss_por_id_3_23': tf.compat.v1.metrics.mean(loss_constraint_list[2][2])
        }

        # log
        id_1_num = tf.reduce_sum(id[0])
        id_1_credit_submit_num = tf.reduce_sum(y[0][3])
        id_1_cvr = id_1_credit_submit_num / id_1_num
        id_1_pcvr = tf.reduce_mean(y_hat[0][3])
        id_2_num = tf.reduce_sum(id[1])
        id_2_credit_submit_num = tf.reduce_sum(y[1][3])
        id_2_cvr = id_2_credit_submit_num / id_2_num
        id_2_pcvr = tf.reduce_mean(y_hat[1][3])
        id_3_num = tf.reduce_sum(id[2])
        id_3_credit_submit_num = tf.reduce_sum(y[2][3])
        id_3_cvr = id_3_credit_submit_num / id_3_num
        id_3_pcvr = tf.reduce_mean(y_hat[2][3])
        sw = tf.reduce_sum(weight)
        logging_info = {
            'id_1_num': id_1_num, 'id_1_credit_submit_num': id_1_credit_submit_num, 'id_1_cvr': id_1_cvr,
            'id_1_pcvr': id_1_pcvr, 'id_1_pcoc': id_1_pcvr/id_1_cvr,
            'id_2_num': id_2_num, 'id_2_credit_submit_num': id_2_credit_submit_num, 'id_2_cvr': id_2_cvr,
            'id_2_pcvr': id_2_pcvr, 'id_2_pcoc': id_2_pcvr/id_2_cvr,
            'id_3_num': id_3_num, 'id_3_credit_submit_num': id_3_credit_submit_num, 'id_3_cvr': id_3_cvr,
            'id_3_pcvr': id_3_pcvr, 'id_3_pcoc': id_3_pcvr/id_3_cvr,
            'sample_weight': sw
        }
        logging_hook = tf.compat.v1.train.LoggingTensorHook(
            logging_info, every_n_iter=params['conf']['eval'].logging_hook_steps)

        if mode == tf.estimator.ModeKeys.EVAL:
            return tf.estimator.EstimatorSpec(
                mode, loss=loss_train, eval_metric_ops=metrics, evaluation_hooks=[logging_hook])

        assert mode == tf.estimator.ModeKeys.TRAIN
        train_op, lr = model.train_function(loss_train)
        logging_hook_ = tf.compat.v1.train.LoggingTensorHook(
            {**logging_info, 'lr': lr}, every_n_iter=params['conf']['train'].logging_hook_steps)

        return tf.estimator.EstimatorSpec(mode, loss=loss_train, train_op=train_op, eval_metric_ops=metrics,
                                          training_hooks=[logging_hook_], evaluation_hooks=[logging_hook])