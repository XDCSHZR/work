# -*- coding: utf-8 -*-
"""
Created on Tue Jul 30 20:30:00 2024

@author: jarretthan
"""

import sys

from utils_ import dchat

FLAG = sys.argv[1]
CONTENT = sys.argv[2]

if __name__ == '__main__':
    dchat(FLAG, content=CONTENT)
