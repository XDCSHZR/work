# -*- coding: utf-8 -*-
"""
Created on Tue Jul 9 20:15:00 2024

@author: jarretthan
"""

import pandas as pd
import sys
import warnings
import os

from sklearn.metrics import roc_auc_score


warnings.filterwarnings('ignore')

score_file_path = sys.argv[1]
para_version = sys.argv[2]
model_version = sys.argv[3]
auc_file_path = sys.argv[4]


if __name__ == '__main__':
    df_pred = pd.read_csv(score_file_path, sep='\t', encoding='utf-8')

    domain_id = [1, 2, 3]

    # print(model_version)
    # print('adj version {}'.format(para_version))

    df_auc = pd.DataFrame(
        {
            'model_version': [],
            'domain_id': [],
            'obs_dt': [],
            'num': [],
            'labels': [],
            'auc': [],
            'pcoc': [],
            'pcoc_adj': []
        }
    )
    if not os.path.exists(auc_file_path):
        df_auc.to_csv(auc_file_path, index=False, sep='\t')

    for id in domain_id:
        # print('domain id {}'.format(id))

        df_id = df_pred[df_pred['domain_id'] == id]
        # print(df_id.shape[0])

        if para_version == '20240205':
            if id == 1:
                df_id['pred_id_{}_credit_submit_'.format(id)] = df_id['pred_id_{}_credit_submit'.format(id)].apply(
                    lambda x: x / (x + (1 - x) * (1 - 0.9377911548476066)
                                   + (1 - x) * 0.9377911548476066 / 0.09849935736556771))
            elif id == 2:
                df_id['pred_id_{}_credit_submit_'.format(id)] = df_id['pred_id_{}_credit_submit'.format(id)].apply(
                    lambda x: x / (x + (1 - x) * (1 - 0.8105118524187599)
                                   + (1 - x) * 0.8105118524187599 / 0.09415612922269644))
            else:
                df_id['pred_id_{}_credit_submit_'.format(id)] = df_id['pred_id_{}_credit_submit'.format(id)].apply(
                    lambda x: x / (x + (1 - x) * (1 - 0.8750140822578863)
                                   + (1 - x) * 0.8750140822578863 / 0.08349293878299816))
        else:  # 20231002
            if id == 1:
                df_id['pred_id_{}_credit_submit_'.format(id)] = df_id['pred_id_{}_credit_submit'.format(id)].apply(
                    lambda x: x / (x + (1 - x) * (1 - 0.9186429163789209)
                                   + (1 - x) * 0.9186429163789209 / 0.08606626168330675))
            elif id == 2:
                df_id['pred_id_{}_credit_submit_'.format(id)] = df_id['pred_id_{}_credit_submit'.format(id)].apply(
                    lambda x: x / (x + (1 - x) * (1 - 0.7960788340947828)
                                   + (1 - x) * 0.7960788340947828 / 0.10122767660844768))
            else:
                df_id['pred_id_{}_credit_submit_'.format(id)] = df_id['pred_id_{}_credit_submit'.format(id)].apply(
                    lambda x: x / (x + (1 - x) * (1 - 0.8813389477562102)
                                   + (1 - x) * 0.8813389477562102 / 0.10771921118675858))

        # print('id_{}_credit_submit, AUC:{}, PCOC:{}, PCOC_adj:{}'.format(
        #     id,
        #     roc_auc_score(df_id['label_credit_submit'], df_id['pred_id_{}_credit_submit'.format(id)]),
        #     df_id['pred_id_{}_credit_submit'.format(id)].mean() / df_id['label_credit_submit'].mean(),
        #     df_id['pred_id_{}_credit_submit_'.format(id)].mean() / df_id['label_credit_submit'].mean()))

        df_auc_tmp = pd.DataFrame(
            {
                'model_version': [model_version],
                'domain_id': [id],
                'obs_dt': [df_pred.loc[0, 'obs_dt']],
                'num': [df_id.shape[0]],
                'labels': [df_id['label_credit_submit'].sum()],
                'auc': [roc_auc_score(df_id['label_credit_submit'], df_id['pred_id_{}_credit_submit'.format(id)])],
                'pcoc': [df_id['pred_id_{}_credit_submit'.format(id)].mean() / df_id['label_credit_submit'].mean()],
                'pcoc_adj': [df_id['pred_id_{}_credit_submit_'.format(id)].mean() / df_id['label_credit_submit'].mean()]
            }
        )
        df_auc_tmp.to_csv(auc_file_path, index=False, mode='a', header=None, sep='\t')
