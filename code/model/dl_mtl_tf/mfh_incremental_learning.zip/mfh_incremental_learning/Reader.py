# -*- coding: utf-8 -*-
"""
Created on Mon Jun 25 11:30:00 2024

@author: jarretthan
"""

import tensorflow as tf


class Reader:
    def __init__(self, columns, shuffle=True, pred=False):
        self.shuffle = shuffle
        self.pred = pred
        
        columns_ = columns['emb_columns'] + columns['numeric_columns'] + \
                  columns['sms_emb'] + columns['sms_numeric'] + \
                  columns['wa_emb'] + columns['wa_numeric']
        self.features_parse = tf.feature_column.make_parse_example_spec(feature_columns=columns_)

        if self.pred:
            info = {
                'uid': tf.io.FixedLenFeature(shape=[1], dtype=tf.string, default_value='null'),
                'obs_dt': tf.io.FixedLenFeature(shape=[1], dtype=tf.string, default_value='null'),
                'features_date': tf.io.FixedLenFeature(shape=[1], dtype=tf.string, default_value='null'),
                'domain_id': tf.io.FixedLenFeature(shape=[1], dtype=tf.int64, default_value=-1),
                'id_1': tf.io.FixedLenFeature(shape=[1], dtype=tf.int64, default_value=0),
                'id_2': tf.io.FixedLenFeature(shape=[1], dtype=tf.int64, default_value=0),
                'id_3': tf.io.FixedLenFeature(shape=[1], dtype=tf.int64, default_value=0),
                'label_exposure': tf.io.FixedLenFeature(shape=[1], dtype=tf.int64, default_value=0),
                'label_register': tf.io.FixedLenFeature(shape=[1], dtype=tf.int64, default_value=0),
                'label_credit_apply': tf.io.FixedLenFeature(shape=[1], dtype=tf.int64, default_value=0),
                'label_credit_submit': tf.io.FixedLenFeature(shape=[1], dtype=tf.int64, default_value=0)
            }
        else:
            info = {
                'uid': tf.io.FixedLenFeature(shape=[1], dtype=tf.string, default_value='null'),
                'obs_dt': tf.io.FixedLenFeature(shape=[1], dtype=tf.string, default_value='null'),
                'features_date': tf.io.FixedLenFeature(shape=[1], dtype=tf.string, default_value='null'),
                'domain_id': tf.io.FixedLenFeature(shape=[1], dtype=tf.int64, default_value=-1),
                'id_1': tf.io.FixedLenFeature(shape=[1], dtype=tf.int64, default_value=0),
                'id_2': tf.io.FixedLenFeature(shape=[1], dtype=tf.int64, default_value=0),
                'id_3': tf.io.FixedLenFeature(shape=[1], dtype=tf.int64, default_value=0),
                'label_exposure': tf.io.FixedLenFeature(shape=[1], dtype=tf.int64, default_value=0),
                'label_register': tf.io.FixedLenFeature(shape=[1], dtype=tf.int64, default_value=0),
                'label_credit_apply': tf.io.FixedLenFeature(shape=[1], dtype=tf.int64, default_value=0),
                'label_credit_submit': tf.io.FixedLenFeature(shape=[1], dtype=tf.int64, default_value=0)
            }
        self.features_parse.update(info)

    def generate_parse_fn(self, examples):
        data = tf.io.parse_example(serialized=examples, features=self.features_parse)
        if self.pred:
            return data
        else:
            labels = {
                'domain_id': data['domain_id'],
                'id_1': data['id_1'],
                'id_2': data['id_2'],
                'id_3': data['id_3'],
                'label_exposure': data['label_exposure'],
                'label_register': data['label_register'],
                'label_credit_apply': data['label_credit_apply'],
                'label_credit_submit': data['label_credit_submit']
            }

        return data, labels

    def input_fn(self, file_names, batch_size, shuffle_seed, epoch=None):
        files = tf.data.Dataset.list_files(file_names, shuffle=self.shuffle)
        dataset = files.apply(tf.data.experimental.parallel_interleave(tf.data.TFRecordDataset, cycle_length=4 * 2))
        if self.shuffle:
            dataset = dataset.prefetch(buffer_size=batch_size * 100)
            dataset = dataset.shuffle(buffer_size=batch_size * 100, seed=shuffle_seed)
            dataset = dataset.repeat(epoch)
        dataset = dataset.batch(batch_size)
        dataset = dataset.map(self.generate_parse_fn, num_parallel_calls=32)
        dataset = dataset.prefetch(10)
        iterator = tf.compat.v1.data.make_one_shot_iterator(dataset)

        return iterator.get_next()
