# -*- coding: utf-8 -*-
"""
Created on Fri Jun 28 11:10:00 2024

@author: jarretthan
"""

import numpy as np
import tensorflow as tf

from conf_args import Configuration_argsparse
from layer.DCN import DCN
from layer.DNN import DNN
from layer.CGC import CGC
from layer.AIT import Attention, Info
from layer.Prediction import Prediction


if __name__ == '__main__':
    conf_args = Configuration_argsparse()

    # input
    inputs = tf.constant(np.random.rand(5, 4), shape=[5, 4], dtype=np.float32)

    id_1 = tf.constant(np.array([[1], [0], [0], [0], [1]]), shape=[5, 1], dtype=np.float32)
    id_2 = tf.constant(np.array([[0], [1], [0], [1], [0]]), shape=[5, 1], dtype=np.float32)
    id_3 = tf.constant(np.array([[0], [0], [1], [0], [0]]), shape=[5, 1], dtype=np.float32)

    label_exp = tf.constant(np.array([[0], [1], [1], [1], [1]]), shape=[5, 1], dtype=np.float32)
    label_reg = tf.constant(np.array([[0], [0], [1], [1], [1]]), shape=[5, 1], dtype=np.float32)
    label_c_a = tf.constant(np.array([[0], [0], [0], [1], [1]]), shape=[5, 1], dtype=np.float32)
    label_c_s = tf.constant(np.array([[0], [0], [0], [0], [1]]), shape=[5, 1], dtype=np.float32)

    y_id_1_exp, y_id_1_reg, y_id_1_c_a, y_id_1_c_s = \
        id_1 * label_exp, id_1 * label_reg, id_1 * label_c_a, id_1 * label_c_s
    y_id_2_exp, y_id_2_reg, y_id_2_c_a, y_id_2_c_s = \
        id_2 * label_exp, id_2 * label_reg, id_2 * label_c_a, id_2 * label_c_s
    y_id_3_exp, y_id_3_reg, y_id_3_c_a, y_id_3_c_s = \
        id_3 * label_exp, id_3 * label_reg, id_3 * label_c_a, id_3 * label_c_s

    y = [
        [y_id_1_exp, y_id_1_reg, y_id_1_c_a, y_id_1_c_s],
        [y_id_2_exp, y_id_2_reg, y_id_2_c_a, y_id_2_c_s],
        [y_id_3_exp, y_id_3_reg, y_id_3_c_a, y_id_3_c_s]
    ]

    id = [id_1, id_2, id_3]

    # model
    with tf.device('/cpu:0'):
        # level 0
        with tf.compat.v1.variable_scope(conf_args.conf.Model.level_0.name):
            sb_dcn = DCN(conf_args.conf.Model.level_0.name,
                         conf_args.conf.Model.level_0.deep_layers_units,
                         conf_args.conf.Model.level_0.cross_layer_num,
                         activation=conf_args.conf.Model.level_0.deep_activation,
                         init_seed=conf_args.conf.Seed,
                         reg_l2=conf_args.conf.Model.level_0.deep_regularizer_L2,
                         dropout_rate=conf_args.conf.Model.level_0.deep_dropout_rate,
                         use_bn=conf_args.conf.Model.level_0.deep_use_bn)
            level_0_outputs = sb_dcn.build_call(inputs, tf.estimator.ModeKeys.TRAIN)  # [5,260]
            level_0_outputs = [level_0_outputs for _ in range(conf_args.conf.Model.level_0.num_tasks)]  # [[5,260]*2]

        # level 1
        level_1 = []
        level_1_task_num = []
        with tf.compat.v1.variable_scope(conf_args.conf.Model.level_1.name):
            conf_tmp_1 = [x for x in conf_args.conf.Model.level_1.items() if x[0] not in ['name']]
            for _, v in conf_tmp_1:
                level_1_tmp = [
                    DNN(v.MLP.name,
                        v.MLP.layers_units,
                        activation=v.MLP.activation,
                        init_seed=conf_args.conf.Seed,
                        reg_l2=v.MLP.regularizer_L2,
                        dropout_rate=v.MLP.dropout_rate,
                        use_bn=v.MLP.use_bn),
                    CGC(v.Switcher.name,
                        v.Switcher.specific_expert_nums,
                        v.Switcher.specific_expert_layers_units,
                        v.Switcher.share_expert_nums,
                        v.Switcher.share_expert_layers_units,
                        v.Switcher.num_tasks,
                        activation=v.Switcher.activation,
                        init_seed=conf_args.conf.Seed,
                        reg_l2=v.Switcher.regularizer_L2,
                        dropout_rate=v.Switcher.dropout_rate,
                        use_bn=v.Switcher.use_bn)
                ]
                level_1.append(level_1_tmp)
                level_1_task_num.append(v.Switcher.num_tasks)

            level_1_outputs = [
                level_1[i][1].build_call(  # [[5,256]*3\4]
                    level_1[i][0].build_call(level_0_outputs[i], tf.estimator.ModeKeys.TRAIN), tf.estimator.ModeKeys.TRAIN)
                for i in range(conf_args.conf.Model.level_0.num_tasks)
            ]  # [[[5,256]*3],[[5,256]*4]]
            level_1_outputs_ = []  # [[5,256]*7]
            for x in level_1_outputs:
                level_1_outputs_ += x

        # level 2
        level_2 = []
        level_2_task_num = []
        with tf.compat.v1.variable_scope(conf_args.conf.Model.level_2.name):
            conf_tmp_2 = [x for x in conf_args.conf.Model.level_2.items() if x[0] not in ['name']]
            for _, v in conf_tmp_2:
                level_2_tmp = [
                    DNN(v.MLP.name,
                        v.MLP.layers_units,
                        activation=v.MLP.activation,
                        init_seed=conf_args.conf.Seed,
                        reg_l2=v.MLP.regularizer_L2,
                        dropout_rate=v.MLP.dropout_rate,
                        use_bn=v.MLP.use_bn),
                    CGC(v.Switcher.name,
                        v.Switcher.specific_expert_nums,
                        v.Switcher.specific_expert_layers_units,
                        v.Switcher.share_expert_nums,
                        v.Switcher.share_expert_layers_units,
                        v.Switcher.num_tasks,
                        activation=v.Switcher.activation,
                        init_seed=conf_args.conf.Seed,
                        reg_l2=v.Switcher.regularizer_L2,
                        dropout_rate=v.Switcher.dropout_rate,
                        use_bn=v.Switcher.use_bn)
                ]
                level_2.append(level_2_tmp)
                level_2_task_num.append(v.Switcher.num_tasks)

            level_2_outputs = [
                level_2[i][1].build_call(  # [[5,64]*4/3]
                    level_2[i][0].build_call(level_1_outputs_[i], tf.estimator.ModeKeys.TRAIN), tf.estimator.ModeKeys.TRAIN)
                for i in range(sum(level_1_task_num))
            ]  # [[[5,64]*4]*3,[[5,64]*3]*4]

        # tower
        tower_inputs_0 = level_2_outputs[0] + level_2_outputs[1] + level_2_outputs[2]  # [[5,64]*12]
        tower_inputs_1 = [
            [level_2_outputs[3:][j][i] for j in range(len(level_2_task_num[3:]))]
            for i in range(level_2_task_num[3:][0])
        ]  # [[[5,64]*4]*3]
        tower_inputs_1_ = []  # [[5,64]*12]
        for x in tower_inputs_1:
            tower_inputs_1_ += x

        with tf.compat.v1.variable_scope(conf_args.conf.Model.Tower.name):
            tower_num = sum(level_2_task_num) // conf_args.conf.Model.level_0.num_tasks
            link_num = tower_num // level_1_task_num[-1]
            info_num = tower_num - link_num
            ait_num = tower_num - link_num
            ait_link_num = ait_num // link_num

            tower_base = [
                DNN(conf_args.conf.Model.Tower.base.name + '_{}'.format(i),
                    conf_args.conf.Model.Tower.base.layers_units,
                    activation=conf_args.conf.Model.Tower.base.activation,
                    init_seed=conf_args.conf.Seed,
                    reg_l2=conf_args.conf.Model.Tower.base.regularizer_L2,
                    dropout_rate=conf_args.conf.Model.Tower.base.dropout_rate,
                    use_bn=conf_args.conf.Model.Tower.base.use_bn)
                for i in range(tower_num)
            ]
            tower_base_outputs = [
                tower_base[i].build_call(tower_inputs_0[i] + tower_inputs_1_[i], tf.estimator.ModeKeys.TRAIN)
                for i in range(tower_num)
            ]  # [[5,32]*12]
            tower_base_outputs = [
                tower_base_outputs[(level_1_task_num[-1] * i):(level_1_task_num[-1] * (i + 1))]
                for i in range(link_num)
            ]  # [[[5,32]*4]*3]

            info = [
                Info(conf_args.conf.Model.Tower.AIT.name + '_info_{}'.format(i),
                     conf_args.conf.Model.Tower.AIT.info_units,
                     activation=conf_args.conf.Model.Tower.AIT.info_activation,
                     init_seed=conf_args.conf.Seed,
                     reg_l2=conf_args.conf.Model.Tower.AIT.info_regularizer_L2,
                     dropout_rate=conf_args.conf.Model.Tower.AIT.info_dropout_rate,
                     use_bn=conf_args.conf.Model.Tower.AIT.info_use_bn)
                for i in range(info_num)
            ]
            ait = [
                Attention(conf_args.conf.Model.Tower.AIT.name + '_ait_{}'.format(i),
                          conf_args.conf.Model.Tower.AIT.attention_units,
                          init_seed=conf_args.conf.Seed,
                          reg_l2=conf_args.conf.Model.Tower.base.regularizer_L2)
                for i in range(ait_num)
            ]

            ait_outputs = []  # [[[5,32]*4]*3]
            info_outputs = []  # [[[5,32]*3]*3]
            for i in range(link_num):
                ait_outputs_tmp = [tower_base_outputs[i][0]]
                info_outputs_tmp = []
                for j in range(ait_link_num):
                    info_ = info[i * ait_link_num + j].build_call(ait_outputs_tmp[-1], tf.estimator.ModeKeys.TRAIN)
                    info_outputs_tmp.append(info_)
                    ait_ = ait[i * ait_link_num + j].build_call(
                        tf.concat([tf.expand_dims(info_outputs_tmp[-1], axis=1),
                                   tf.expand_dims(tower_base_outputs[i][j + 1], axis=1)], axis=1)
                    )
                    ait_outputs_tmp.append(ait_)
                ait_outputs.append(ait_outputs_tmp)
                info_outputs.append(info_outputs_tmp)

            tower_head = [
                Prediction(conf_args.conf.Model.Tower.head.name + '_{}'.format(i),
                           conf_args.conf.Model.Tower.head.layers_units,
                           activation=conf_args.conf.Model.Tower.head.activation,
                           init_seed=conf_args.conf.Seed,
                           reg_l2=conf_args.conf.Model.Tower.head.regularizer_L2,
                           dropout_rate=conf_args.conf.Model.Tower.head.dropout_rate,
                           use_bn=conf_args.conf.Model.Tower.head.use_bn)
                for i in range(tower_num)
            ]
            tower_head_outputs = [
                [
                    tower_head[i * level_1_task_num[-1] + j].build_call(ait_outputs[i][j], tf.estimator.ModeKeys.TRAIN)
                    for j in range(level_1_task_num[-1])
                ]
                for i in range(link_num)
            ]  # [[[5,1]*4]*3]

    # loss
    loss = []
    loss_constraint = []
    for i in range(len(conf_args.conf.Train.loss_weights)):
        with tf.compat.v1.name_scope('id_{}'.format(i)):
            loss_tmp = [
                tf.compat.v1.losses.log_loss(y[i][j], tower_head_outputs[i][j], reduction='none')
                for j in range(len(conf_args.conf.Train.loss_weights[i]))
            ]
            loss.append(loss_tmp)

            loss_constraint_tmp = [
                tf.maximum(tower_head_outputs[i][j + 1] - tower_head_outputs[i][j], 0)
                for j in range(len(conf_args.conf.Train.loss_constraint_weights[i]))
            ]
            loss_constraint.append(loss_constraint_tmp)

    loss_sum = 0
    loss_constraint_sum = 0
    loss_list = []
    loss_constraint_list = []
    for i in range(len(conf_args.conf.Train.loss_weights)):  # 3
        loss_list_tmp = []
        for j in range(len(conf_args.conf.Train.loss_weights[i])):  # 4
            if conf_args.conf.Train.use_mask:
                loss_tmp = conf_args.conf.Train.loss_weights[i][j] * \
                           tf.reduce_mean(tf.multiply(loss[i][j], id[i]))
                loss_sum += loss_tmp
                loss_list_tmp.append(loss_tmp)
            else:
                loss_tmp = conf_args.conf.Train.loss_weights[i][j] * tf.reduce_mean(loss[i][j])
                loss_sum += loss_tmp
                loss_list_tmp.append(loss_tmp)
        loss_list.append(loss_list_tmp)

        loss_constraint_list_tmp = []
        for j in range(len(conf_args.conf.Train.loss_constraint_weights[i])):  # 3
            if conf_args.conf.Train.use_mask:
                loss_constraint_tmp = conf_args.conf.Train.loss_constraint_weights[i][j] * \
                                      tf.reduce_mean(tf.multiply(loss_constraint[i][j], id[i]))
                loss_constraint_sum += loss_constraint_tmp
                loss_constraint_list_tmp.append(loss_constraint_tmp)
            else:
                loss_constraint_tmp = conf_args.conf.Train.loss_constraint_weights[i][j] * \
                                      tf.reduce_mean(loss_constraint[i][j])
                loss_constraint_sum += loss_constraint_tmp
                loss_constraint_list_tmp.append(loss_constraint_tmp)
        loss_constraint_list.append(loss_constraint_list_tmp)

    print('done')
