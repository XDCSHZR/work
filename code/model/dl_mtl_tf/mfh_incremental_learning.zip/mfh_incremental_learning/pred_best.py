# -*- coding: utf-8 -*-
"""
Created on Mon Jul 31 19:30:00 2024

@author: jarretthan
"""

import numpy as np
import functools
import pickle

import pandas as pd
import tensorflow as tf
import warnings

from conf_args import Configuration_argsparse
from Estimator import Estimator
from PreProcess import PreProcess
from Reader import Reader

np.set_printoptions(threshold=np.inf, suppress=True, precision=4, linewidth=np.inf)

tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.INFO)

warnings.filterwarnings('ignore')


class Predictor(object):
    def __init__(self):
        self.est_run_conf = tf.estimator.RunConfig(
            model_dir=conf_args.conf.Output.tf_log_best,
            tf_random_seed=conf_args.conf.Seed,
            save_checkpoints_steps=conf_args.conf.Train.save_checkpoints_steps,
            log_step_count_steps=conf_args.conf.Train.log_step_count_steps
        )

        pkl = open(conf_args.conf.Feature.pkl, 'rb')
        feature_map = pickle.load(pkl)
        pkl.close()

        self.preprocessor = PreProcess(feature_map, conf_args.conf.Seed)
        self.reader = Reader(columns=self.preprocessor.columns, shuffle=False, pred=True)

    def pred(self):
        estimator_ = Estimator(
            est_run_conf=self.est_run_conf,
            feature_columns=self.preprocessor.columns,
            conf={
                'model': conf_args.conf.Model,
                'train': conf_args.conf.Train,
                'eval': conf_args.conf.Eval,
                'seed': conf_args.conf.Seed
            }
        )

        estimator = estimator_.build_estimator()

        pred_input_fn = functools.partial(
            self.reader.input_fn,
            conf_args.args.test_data_path,
            conf_args.conf.Test.batch_size,
            conf_args.conf.Seed,
            conf_args.conf.Test.epochs
        )

        cnt = 0
        for i, res in enumerate(estimator.predict(pred_input_fn, yield_single_examples=False)):
            cnt += min(conf_args.conf.Test.batch_size, len(res['pred_id_1_credit_submit']))
            print('estimator.predict: {} step, {} sample, total {} sample'.
                  format(i, min(conf_args.conf.Test.batch_size, len(res['pred_id_1_credit_submit'])), cnt))

            df = pd.DataFrame(
                {
                    'uid': list(map(lambda x: x.decode('utf-8'), res['uid'].reshape(1, -1)[0].tolist())),
                    'obs_dt': list(map(lambda x: x.decode('utf-8'), res['obs_dt'].reshape(1, -1)[0].tolist())),
                    'features_date':
                        list(map(lambda x: x.decode('utf-8'), res['features_date'].reshape(1, -1)[0].tolist())),
                    'domain_id': res['domain_id'].reshape(1, -1)[0].tolist(),
                    'label_credit_submit': res['label_credit_submit'].reshape(1, -1)[0].tolist(),
                    'pred_id_1_credit_submit':
                        res['pred_id_1_credit_submit'].reshape(1, len(res['pred_id_1_credit_submit']))[0].tolist(),
                    'pred_id_2_credit_submit':
                        res['pred_id_2_credit_submit'].reshape(1, len(res['pred_id_2_credit_submit']))[0].tolist(),
                    'pred_id_3_credit_submit':
                        res['pred_id_3_credit_submit'].reshape(1, len(res['pred_id_3_credit_submit']))[0].tolist()
                }
            )

            if i == 0:
                df.to_csv(conf_args.args.pred_path, index=False, sep='\t')
            else:
                df.to_csv(conf_args.args.pred_path, index=False, mode='a', header=None, sep='\t')


def main(argv=None):
    predictor = Predictor()
    predictor.pred()


if __name__ == '__main__':
    conf_args = Configuration_argsparse()
    print(conf_args.args)
    print(conf_args.conf.Feature)
    print(conf_args.conf.Test)
    print(conf_args.conf.Output)

    # 随机种子
    tf.compat.v1.set_random_seed(conf_args.conf.Seed)

    # 模型预测
    tf.compat.v1.logging.info('----start---')
    tf.compat.v1.app.run()
