# -*- coding: utf-8 -*-
"""
Created on Fri Aug 2 13:30:00 2024

@author: jarretthan
"""

import datetime
import json
import requests


def dchat(flag, content=''):
    text = ''
    if flag == 1:
        text += '{} \n**发生错误，请及时检查!** \n'.format(content)
    else:
        text += content
        text += '\n'

    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    text += '检查时间: ' + now
    postdata = {
        'msgtype': 'markdown',
        'text': 'MTL增量训练监控 @jarretthan ',  # @group 所有人 @jarretthan
        'attachments': [
            {
                'text': text,
                'color': '#ffa500'
            }
        ]
    }

    robot_url = 'http://10.14.128.126/snitch_openapi_online_lb/teams/didichuxing/hooks/incoming/234f4662-1d17-4b50-bce3-af67fdf2542b'
    headers = {'Content-type': 'application/json'}
    postdata_json = json.dumps(postdata)
    response = requests.post(url=robot_url, headers=headers, data=postdata_json)
