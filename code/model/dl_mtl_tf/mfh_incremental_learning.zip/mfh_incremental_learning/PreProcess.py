# -*- coding: utf-8 -*-
"""
Created on Mon Jun 25 11:30:00 2024

@author: jarretthan
"""

import tensorflow as tf
import numpy as np
from utils import minMax
import math


def get_dtype(x):
    if "float" in x:
        return tf.float32, 'tf.float32'
    if "int" in x:
        return tf.int64, 'tf.int64'
    if "string" in x:
        return tf.string, 'tf.string'


class PreProcess:
    def __init__(self, feature_map, init_seed):
        self.feature_map = feature_map
        self.initializer = tf.compat.v1.glorot_normal_initializer(seed=init_seed)
        self.max_norm = None

        self.columns = {}

        self.preprocess()

    def preprocess(self):

        in_fea = {}
        numeric_columns = []
        emb_columns = []
        sms_emb = []
        sms_numeric = []
        wa_emb = []
        wa_numeric = []

        loc = locals()

        for fea in self.feature_map['feature_list']:
            input = self.feature_map[fea]['input']
            process_fun = self.feature_map[fea]['process_func']
            params = self.feature_map[fea]['params']
            length = self.feature_map[fea]['length']
            share_tag = self.feature_map[fea]['share_tag']

            if self.feature_map[fea]['emb_size'] == 'auto':
                emb_size = self.get_auto_embedding_dim(int(length))
            else:
                emb_size = int(self.feature_map[fea]['emb_size'])

            fea_key = eval("'{}'".format(input))
            fea_dtype, fea_dtype_str = get_dtype(self.feature_map[fea]['dtype'])
            default_value = self.feature_map[fea]['default_value']

            if process_fun in ['numeric_continuous', 'numeric_bucket']:  # 连续值处理
                fea_ori = tf.feature_column.numeric_column(key=fea_key, default_value=default_value, dtype=fea_dtype)
                if "numeric_continuous" == process_fun:  # 连续值-归一化
                    if len(params.split('_')) < 3:  # -> 原始值已经在0-1之间
                        fea_normalize = fea_ori
                    else:
                        normalizer_fn = params.split('_')[0]
                        exec(
                            "fea_normalize=tf.feature_column.numeric_column(key='{}',  dtype={} , default_value={}, normalizer_fn=lambda x: minMax(x, '{}'))".format(
                                fea_key, fea_dtype_str, default_value, params))
                        fea_normalize = loc['fea_normalize']
                    if share_tag == 'no':
                        numeric_columns.append(fea_normalize)
                    elif share_tag == 'sms':
                        sms_numeric.append(fea_normalize)
                    elif share_tag == 'wa':
                        wa_numeric.append(fea_normalize)

                if "numeric_bucket" == process_fun:  # 连续值 -> 分桶+embedding
                    params = params.replace('_', ',')
                    boundaries = list(eval(params))
                    buk_col = tf.feature_column.bucketized_column(source_column=fea_ori, boundaries=boundaries)
                    buk_emb = tf.feature_column.embedding_column(categorical_column=buk_col, dimension=emb_size,
                                                                 initializer=self.initializer, max_norm=self.max_norm, combiner='sqrtn')


                    if share_tag == 'no':
                        emb_columns.append(buk_emb)
                    elif share_tag == 'sms':
                        sms_emb.append(buk_emb)
                    elif share_tag == 'wa':
                        wa_emb.append(buk_emb)

            elif "categorical_file" == process_fun:  # id类型 -> embedding
                file_path = './map_test/' + params
                feature_col = tf.feature_column.categorical_column_with_vocabulary_file(key=fea_key,
                                                                                        vocabulary_file=file_path,
                                                                                        vocabulary_size=int(length),
                                                                                        num_oov_buckets=5,
                                                                                        dtype=fea_dtype)
                fea_emb = tf.feature_column.embedding_column(categorical_column=feature_col, dimension=emb_size,
                                                             initializer=self.initializer, max_norm=self.max_norm,combiner='sqrtn'
                                                             )
                if share_tag == 'no':
                    emb_columns.append(fea_emb)
                elif share_tag == 'sms':
                    sms_emb.append(fea_emb)
                elif share_tag == 'wa':
                    wa_emb.append(fea_emb)

            elif "categorical_list" == process_fun:  # id类型 -> embedding 注意类型
                if params == '-':
                    if fea_dtype == tf.int64:
                        vocabulary_list = np.arange(0, int(length)).tolist()
                        vocabulary_list = [int(i) for i in vocabulary_list]
                    else:
                        vocabulary_list = [str(i) for i in np.arange(0, int(length))]
                else:  # 如果有配置
                    vocabulary_list = eval('{}'.format(params))
                feature_col = tf.feature_column.categorical_column_with_vocabulary_list(key=fea_key,
                                                                                        vocabulary_list=vocabulary_list,
                                                                                        num_oov_buckets=500,
                                                                                        dtype=fea_dtype)
                fea_emb = tf.feature_column.embedding_column(categorical_column=feature_col, dimension=emb_size,
                                                             initializer=self.initializer, max_norm=self.max_norm,
                                                             combiner='sum')

                if share_tag == 'no':
                    emb_columns.append(fea_emb)
                elif share_tag == 'sms':
                    sms_emb.append(fea_emb)
                elif share_tag == 'wa':
                    wa_emb.append(fea_emb)

            elif "crossed_column" in process_fun:  # 交叉特征 --暂时不能用 有问题

                cols = self.feature_map[fea]['input'].split('&')

                size = [int(self.feature_map[col]['length']) for col in cols]
                size = np.prod(size)
                exec("cross_col = tf.feature_column.crossed_column(keys=cols, hash_bucket_size={})".format(size))

                cross_col = loc['cross_col']
                exec(
                    "fea_emb = tf.feature_column.embedding_column(categorical_column=cross_col, dimension={},initializer=self.initializer)".format(
                        emb_size))

                fea_emb = loc['fea_emb']
                if share_tag == 'no':
                    emb_columns.append(fea_emb)
                elif share_tag == 'sms':
                    sms_emb.append(fea_emb)
                elif share_tag == 'wa':
                    wa_emb.append(fea_emb)
        self.columns = {'emb_columns': emb_columns, 'numeric_columns': numeric_columns,
                        'sms_emb': sms_emb, 'sms_numeric': sms_numeric,
                        'wa_emb': wa_emb, 'wa_numeric': wa_numeric,
                        }
        return numeric_columns, emb_columns

    def get_auto_embedding_dim(self, num_classes):
        """ Calculate the dim of embedding vector according to number of classes in the category
        emb_dim = [6 * (num_classes)^(1/4)]
        reference: Deep & Cross Network for Ad Click Predictions.(ADKDD'17)
        Args:
            num_classes: number of classes in the category

        Returns:
            the dim of embedding vector
        """
        return math.floor(6 * math.pow(num_classes, 0.26))
