# -*- coding: utf-8 -*-
"""
Created on Thu Jun 27 16:00:00 2024

@author: jarretthan
"""

import tensorflow as tf


class Attention(object):
    def __init__(self, name,
                 units,
                 init_seed=2024, reg_l2=0.0):
        self.name = name
        self.units = units

        self.kernel_initializer = tf.compat.v1.glorot_normal_initializer(seed=init_seed)
        self.kernel_regularizer = tf.keras.regularizers.l2(l=reg_l2)
        self.bias_initializer = tf.compat.v1.zeros_initializer()
        self.bias_regularizer = None

    def build_call(self, inputs):  # inputs: [p;q], [batch_size,2,inputs_dim], p=q=[batch_size,inputs_dim]
        with tf.compat.v1.variable_scope(self.name):
            Q = tf.keras.layers.Dense(
                units=self.units,
                kernel_initializer=self.kernel_initializer,
                kernel_regularizer=self.kernel_regularizer,
                bias_initializer=self.bias_initializer,
                bias_regularizer=self.bias_regularizer)(inputs)  # [batch_size,2,outputs_dim], inputs_dim=outputs_dim
            K = tf.keras.layers.Dense(
                units=self.units,
                kernel_initializer=self.kernel_initializer,
                kernel_regularizer=self.kernel_regularizer,
                bias_initializer=self.bias_initializer,
                bias_regularizer=self.bias_regularizer)(inputs)  # [batch_size,2,outputs_dim]
            V = tf.keras.layers.Dense(
                units=self.units,
                kernel_initializer=self.kernel_initializer,
                kernel_regularizer=self.kernel_regularizer,
                bias_initializer=self.bias_initializer,
                bias_regularizer=self.bias_regularizer)(inputs)  # [batch_size,2,outputs_dim]
            score = tf.reduce_sum(tf.multiply(Q, K), axis=-1) / tf.sqrt(tf.cast(self.units, tf.float32))  # [batch_size,2]
            W = tf.nn.softmax(score, axis=1)  # [batch_size,2]
            outputs = tf.reduce_sum(tf.multiply(tf.expand_dims(W, axis=-1), V), axis=1)  # [batch_size,outputs_dim]

        return outputs


class Info(object):
    def __init__(self, name,
                 units,
                 activation='relu', init_seed=2024, reg_l2=0.0, dropout_rate=0.0, use_bn=False):
        self.name = name
        self.units = units

        self.activation = activation
        self.kernel_initializer = tf.compat.v1.glorot_normal_initializer(seed=init_seed)
        self.kernel_regularizer = tf.keras.regularizers.l2(l=reg_l2)
        self.bias_initializer = tf.compat.v1.zeros_initializer()
        self.bias_regularizer = None

        self.dropout_rate = dropout_rate
        self.use_bn = use_bn

    def build_call(self, inputs, mode):
        outputs = inputs
        with tf.compat.v1.variable_scope(self.name):
            outputs = tf.keras.layers.Dense(
                units=self.units,
                kernel_initializer=self.kernel_initializer,
                kernel_regularizer=self.kernel_regularizer,
                bias_initializer=self.bias_initializer,
                bias_regularizer=self.bias_regularizer)(outputs)  # inputs_dim=outputs_dim
            if self.use_bn:
                outputs = tf.keras.layers.BatchNormalization()(inputs=outputs,
                                                               training=(mode == tf.estimator.ModeKeys.TRAIN))
            outputs = tf.keras.layers.Activation(self.activation)(outputs)
            outputs = tf.keras.layers.Dropout(self.dropout_rate)(inputs=outputs,
                                                                 training=(mode == tf.estimator.ModeKeys.TRAIN))

        return outputs
