# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 12:00:00 2024

@author: jarretthan
"""

import tensorflow as tf


class Dcn(object):
    def __init__(self, deep_layers, cross_layer_num):
        self.deep_layers = deep_layers
        self.cross_layer_num = cross_layer_num
        self.activation = tf.nn.leaky_relu
        self.kernel_initializer = tf.compat.v1.glorot_normal_initializer(seed=2022)
        self.bias_initializer = tf.compat.v1.keras.initializers.VarianceScaling(
            scale=1.0, mode='fan_avg', distribution=("uniform" if False else "truncated_normal"))
        self.regularizer = tf.keras.regularizers.l2(l=0.5 * 0.0001)

    def base_layer(self, concat_vector, mode, name):
        concat_vector_shape = concat_vector.get_shape()[-1]
        concat_vector = tf.reshape(concat_vector, [-1, concat_vector_shape, 1])

        cross_weights = {}
        with tf.compat.v1.variable_scope("cross_part_" + name):
            for i in range(self.cross_layer_num):
                cross_weights['cross_layer_weight_{}{}'.format(i, name)] = tf.compat.v1.get_variable(
                    name='cross_layer_weight_{}{}'.format(i, name),
                    shape=[concat_vector_shape, 1],
                    initializer=self.kernel_initializer,
                    regularizer=self.regularizer)
                cross_weights['cross_layer_bias_{}{}'.format(i, name)] = tf.compat.v1.get_variable(
                    name='cross_layer_bias_{}{}'.format(i, name),
                    shape=[concat_vector_shape, 1],
                    initializer=self.kernel_initializer,
                    regularizer=self.regularizer)
            x_now = concat_vector
            for i in range(self.cross_layer_num):
                xb = tf.tensordot(tf.reshape(x_now, [-1, 1, concat_vector_shape]),
                                  cross_weights['cross_layer_weight_{}{}'.format(i, name)], 1)
                x_now = concat_vector * xb + cross_weights['cross_layer_bias_{}{}'.format(i, name)] + x_now
            cross_network_out = tf.reshape(x_now, [-1, concat_vector_shape])

        with tf.compat.v1.variable_scope("deep_part_" + name):
            concat_vector = tf.reshape(concat_vector, [-1, concat_vector_shape])
            for units in self.deep_layers:
                concat_vector = tf.keras.layers.Dense(
                    units=units,
                    activation=self.activation,
                    kernel_initializer=self.kernel_initializer,
                    kernel_regularizer=self.regularizer,
                    bias_initializer=self.kernel_initializer,
                    bias_regularizer=None)(concat_vector)
                concat_vector = tf.compat.v1.layers.dropout(inputs=concat_vector, rate=0.0,
                                                            training=(mode == tf.estimator.ModeKeys.TRAIN))

        return tf.concat([cross_network_out, concat_vector], axis=-1)
