# -*- coding: utf-8 -*-
"""
Created on Mon Jun 25 21:30:00 2024

@author: jarretthan
"""

import tensorflow as tf


class DNN(object):
    def __init__(self, name,
                 layers_units,
                 activation='relu', init_seed=2024, reg_l2=0.0, dropout_rate=0.0, use_bn=False):
        self.name = name
        self.layers_units = layers_units

        self.activation = activation
        self.kernel_initializer = tf.compat.v1.glorot_normal_initializer(seed=init_seed)
        self.kernel_regularizer = tf.keras.regularizers.l2(l=reg_l2)
        self.bias_initializer = tf.compat.v1.zeros_initializer()
        self.bias_regularizer = None

        self.dropout_rate = dropout_rate
        self.use_bn = use_bn

    def build_call(self, inputs, mode):
        outputs = inputs
        with tf.compat.v1.variable_scope(self.name):
            for units in self.layers_units:
                outputs = tf.keras.layers.Dense(
                    units=units,
                    kernel_initializer=self.kernel_initializer,
                    kernel_regularizer=self.kernel_regularizer,
                    bias_initializer=self.bias_initializer,
                    bias_regularizer=self.bias_regularizer)(outputs)
                if self.use_bn:
                    outputs = tf.keras.layers.BatchNormalization()(inputs=outputs,
                                                                   training=(mode == tf.estimator.ModeKeys.TRAIN))
                outputs = tf.keras.layers.Activation(self.activation)(outputs)
                outputs = tf.keras.layers.Dropout(self.dropout_rate)(inputs=outputs,
                                                                     training=(mode == tf.estimator.ModeKeys.TRAIN))

        return outputs
