# -*- coding: utf-8 -*-
"""
Created on Mon Jun 25 17:00:00 2024

@author: jarretthan
"""

import tensorflow as tf

from layer.DNN import DNN


class DCN(object):
    def __init__(self, name,
                 deep_layers_units, cross_layers_num,
                 activation='relu', init_seed=2024, reg_l2=0.0, dropout_rate=0.0, use_bn=False):
        self.name = name
        self.deep_layers_units = deep_layers_units
        self.cross_layers_num = cross_layers_num
        
        self.kernel_initializer = tf.compat.v1.glorot_normal_initializer(seed=init_seed)
        self.kernel_regularizer = tf.keras.regularizers.l2(l=reg_l2)
        self.bias_initializer = tf.compat.v1.zeros_initializer()
        self.bias_regularizer = None

        self.activation = activation
        self.init_seed = init_seed
        self.reg_l2 = reg_l2
        self.dropout_rate = dropout_rate
        self.use_bn = use_bn

    def build_call(self, inputs, mode):
        inputs_shape = inputs.get_shape()[-1]  # 700+
        inputs = tf.reshape(inputs, [-1, inputs_shape, 1])

        cross_weights = {}
        with tf.compat.v1.variable_scope(self.name+'_cross_part'):
            for i in range(self.cross_layers_num):
                cross_weights['cross_layer_weight_{}'.format(i)] = tf.compat.v1.get_variable(
                    name='cross_layer_weight_{}'.format(i),
                    shape=[inputs_shape, 1],
                    initializer=self.kernel_initializer,
                    regularizer=self.kernel_regularizer)
                cross_weights['cross_layer_bias_{}'.format(i)] = tf.compat.v1.get_variable(
                    name='cross_layer_bias_{}'.format(i),
                    shape=[inputs_shape, 1],
                    initializer=self.bias_initializer,
                    regularizer=self.bias_regularizer)
            x_now = inputs
            for i in range(self.cross_layers_num):
                xb = tf.tensordot(tf.reshape(x_now, [-1, 1, inputs_shape]),
                                  cross_weights['cross_layer_weight_{}'.format(i)], 1)
                x_now = inputs * xb + cross_weights['cross_layer_bias_{}'.format(i)] + x_now
            cross_network_out = tf.reshape(x_now, [-1, inputs_shape])

        inputs = tf.reshape(inputs, [-1, inputs_shape])
        dnn = DNN(self.name+'_deep_part',
                  self.deep_layers_units,
                  activation=self.activation,
                  init_seed=self.init_seed,
                  reg_l2=self.reg_l2,
                  dropout_rate=self.dropout_rate,
                  use_bn=self.use_bn)
        inputs = dnn.build_call(inputs, mode)

        return tf.concat([cross_network_out, inputs], axis=-1)
