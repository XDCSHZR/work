# -*- coding: utf-8 -*-
"""
Created on Thu Jun 27 20:40:00 2024

@author: jarretthan
"""

import tensorflow as tf

from layer.DNN import DNN


class Prediction(object):
    def __init__(self, name,
                 layers_units,
                 activation='relu', init_seed=2024, reg_l2=0.0, dropout_rate=0.0, use_bn=False):
        self.name = name
        self.layers_units = layers_units

        self.kernel_initializer = tf.compat.v1.glorot_normal_initializer(seed=init_seed)
        self.kernel_regularizer = tf.keras.regularizers.l2(l=reg_l2)
        self.bias_initializer = tf.compat.v1.zeros_initializer()
        self.bias_regularizer = None

        self.activation = activation
        self.init_seed = init_seed
        self.reg_l2 = reg_l2
        self.dropout_rate = dropout_rate
        self.use_bn = use_bn

    def build_call(self, inputs, mode):
        mlp_inputs = inputs
        with tf.compat.v1.variable_scope(self.name):
            # inputs MLP
            if len(self.layers_units) > 0:
                dnn = DNN(self.name + '_inputs_MLP',
                          self.layers_units,
                          activation=self.activation,
                          init_seed=self.init_seed,
                          reg_l2=self.reg_l2,
                          dropout_rate=self.dropout_rate,
                          use_bn=self.use_bn)
                mlp_inputs = dnn.build_call(mlp_inputs, mode)

            # Prediction
            with tf.compat.v1.variable_scope(self.name+'_Prediction'):
                outputs = tf.keras.layers.Dense(
                    units=1,
                    activation='sigmoid',
                    kernel_initializer=self.kernel_initializer,
                    kernel_regularizer=self.kernel_regularizer,
                    bias_initializer=self.bias_initializer,
                    bias_regularizer=self.bias_regularizer)(mlp_inputs)

        return outputs
