# -*- coding: utf-8 -*-
"""
Created on Tue Jun 26 11:10:00 2024

@author: jarretthan
"""

import tensorflow as tf

from layer.DNN import DNN
from layer.Gate import Gate


class CGC(object):
    def __init__(self, name,
                 specific_expert_nums, specific_expert_layers_units,
                 share_expert_nums, share_expert_layers_units,
                 num_tasks,
                 activation='relu', init_seed=2024, reg_l2=0.0, dropout_rate=0.0, use_bn=False):
        self.name = name

        self.specific_expert_nums = specific_expert_nums
        self.specific_expert_layers_units = specific_expert_layers_units

        self.share_expert_nums = share_expert_nums
        self.share_expert_layers_units = share_expert_layers_units

        self.num_tasks = num_tasks

        self.kernel_initializer = tf.compat.v1.glorot_normal_initializer(seed=init_seed)
        self.kernel_regularizer = tf.keras.regularizers.l2(l=reg_l2)
        self.bias_initializer = tf.compat.v1.zeros_initializer()
        self.bias_regularizer = None

        self.activation = activation
        self.init_seed = init_seed
        self.reg_l2 = reg_l2
        self.dropout_rate = dropout_rate
        self.use_bn = use_bn

    def build_call(self, inputs, mode):
        with tf.compat.v1.variable_scope(self.name):
            # specific expert
            specific_experts = [
                [
                    DNN(self.name + '_specific_experts_{}_{}'.format(i, j),
                        self.specific_expert_layers_units,
                        activation=self.activation,
                        init_seed=self.init_seed,
                        reg_l2=self.reg_l2,
                        dropout_rate=self.dropout_rate,
                        use_bn=self.use_bn)
                    for j in range(self.specific_expert_nums)
                ] for i in range(self.num_tasks)
            ]
            specific_experts_outputs = [
                [
                    specific_experts[i][j].build_call(inputs, mode)  # [batch_size,outputs_dim]
                    for j in range(self.specific_expert_nums)
                ] for i in range(self.num_tasks)
            ]
            specific_experts_outputs = [
                tf.concat([
                    tf.reshape(task_expert_outputs, [-1, 1, task_expert_outputs.get_shape()[-1]])  # [batch_size,1,outputs_dim]
                    for task_expert_outputs in specific_experts_outputs[i]], axis=1)  # [batch_size,task_expert_num,outputs_dim]
                for i in range(self.num_tasks)
            ]

            # share expert
            share_experts = [
                DNN(self.name + '_share_experts_{}'.format(i),
                    self.share_expert_layers_units,
                    activation=self.activation,
                    init_seed=self.init_seed,
                    reg_l2=self.reg_l2,
                    dropout_rate=self.dropout_rate,
                    use_bn=self.use_bn)
                for i in range(self.share_expert_nums)
            ]
            share_experts_outputs = [
                share_experts[i].build_call(inputs, mode)  # [batch_size,outputs_dim]
                for i in range(self.share_expert_nums)
            ]
            share_experts_outputs = tf.concat([
                tf.reshape(expert_outputs, [-1, 1, expert_outputs.get_shape()[-1]])  # [batch_size,1,outputs_dim]
                for expert_outputs in share_experts_outputs], axis=1)  # [batch_size,share_expert_num,outputs_dim], [;]

            # task gate
            task_gates = [
                Gate(self.name + '_task_gate_{}'.format(i),
                     [self.specific_expert_nums+self.share_expert_nums],  # [2+2]
                     activation=self.activation,
                     init_seed=self.init_seed,
                     reg_l2=self.reg_l2,
                     dropout_rate=self.dropout_rate,
                     use_bn=self.use_bn)
                for i in range(self.num_tasks)
            ]
            task_gates_weights = [
                task_gates[i].build_call(inputs, mode)  # [batch_size,task_expert_num+share_expert_num]
                for i in range(self.num_tasks)
            ]
            task_gates_weights = [
                tf.expand_dims(task_gates_weights[i], axis=-1)  # [batch_size,task_expert_num+share_expert_num, 1]
                for i in range(self.num_tasks)
            ]

            # expert outputs
            experts_outputs = [
                tf.concat([specific_experts_outputs[i], share_experts_outputs], axis=1)  # [batch_size,task_expert_num+share_expert_num,outputs_dim]
                for i in range(self.num_tasks)
            ]
            experts_outputs = [
                tf.matmul(experts_outputs[i], task_gates_weights[i], transpose_a=True)  # [batch_size,outputs_dim,1]
                for i in range(self.num_tasks)
            ]
            experts_outputs = [
                tf.squeeze(experts_outputs[i], axis=-1)  # [batch_size,outputs_dim]
                for i in range(self.num_tasks)
            ]

            return experts_outputs
