# -*- coding: utf-8 -*-
"""
Created on Fri Jun 21 17:50:00 2024

@author: jarretthan
"""

import argparse
import os

from dynaconf import Dynaconf


class Configuration_argsparse(object):
    def __init__(self):
        self.args = self.args_parse()
        self.conf = self.get_config(self.args.config_path)

    @staticmethod
    def args_parse():
        parser = argparse.ArgumentParser(description='args')
        # parser.add_argument('--train_data_path', default='./data/train/part-r-*', type=str, help='训练集路径')
        # parser.add_argument('--eval_data_path', default='./data/eval/part-r-00000', type=str, help='验证集路径')
        # parser.add_argument('--test_data_path', default='./data/eval/part-r-00000', type=str, help='测试集路径')
        parser.add_argument('--train_data_path', default='./data/part-r-00000', type=str, help='训练集路径')
        parser.add_argument('--eval_data_path', default='./data/part-r-00000', type=str, help='验证集路径')
        parser.add_argument('--test_data_path', default='./data/part-r-00000', type=str, help='测试集路径')
        parser.add_argument('--pred_path', default='./data/pred_res/pred_res.csv', type=str, help='预测输出路径')
        parser.add_argument('--config_path', default='./model_config/mfh_aitm.yaml', type=str, help='配置文件路径')
        args = parser.parse_args()
        return args

    def get_config(self, conf_path):
        """
        get config from configuration direction, supported file formats: yaml
        """
        if not os.path.exists(conf_path):
            raise Exception('config file not found')

        if os.path.isfile(conf_path):
            conf_list = [conf_path]
        else:
            conf_list = []
            for root, _, files in os.walk(conf_path):
                for file in files:
                    if os.path.splitext(file)[1] == '.yaml':  # yaml files
                        conf_list.append(os.path.join(root, file))

        if not conf_list:
            raise Exception("config file not found")

        settings = Dynaconf(
            envvar_prefix="DYNACONF",
            settings_files=conf_list,
        )
        return settings
