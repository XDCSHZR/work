# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 12:00:00 2024

@author: jarretthan
"""

import tensorflow as tf

from layer.DCN import DCN


class SB_DCN(object):
    def __init__(self):
        self.learning_rate = 0.0005
        self.activation = tf.nn.leaky_relu
        self.kernel_initializer = tf.compat.v1.glorot_normal_initializer(seed=2022)
        self.bias_initializer = tf.compat.v1.keras.initializers.VarianceScaling(
            scale=1.0, mode='fan_avg', distribution=('uniform' if False else 'truncated_normal'))
        self.regularizer = tf.keras.regularizers.l2(l=0.5 * 0.0001)

    def num_null_deal(self, numeric_tmp, name):
        miss_variable = tf.compat.v1.get_variable(shape=[1, numeric_tmp.get_shape()[-1]],
                                                  name="missing_var_" + name,
                                                  initializer=self.kernel_initializer,
                                                  regularizer=self.regularizer)
        flag = tf.less(numeric_tmp, 0)
        flag = tf.cast(flag, tf.float32)

        numeric = tf.multiply(flag, miss_variable) + tf.multiply((1 - flag), numeric_tmp)
        return numeric

    def inference(self, numeric_columns, deep_feature, mode, id1, id2, id3):
        name = 'share'
        with tf.device('/cpu:0'):
            numeric_tmp = tf.concat(numeric_columns, axis=-1)
            emb = tf.concat(deep_feature, axis=-1)

            # 连续值缺失值处理
            with tf.compat.v1.variable_scope("missing_value_" + name):
                share_numeric = self.num_null_deal(numeric_tmp, name)

            with tf.compat.v1.variable_scope("concat_all_" + name):
                concat_vector = tf.concat([share_numeric, emb], axis=-1)
                dcn = Dcn([256, 128, 64], 2)
                share_layer = dcn.base_layer(concat_vector, mode, 'share')

        a_loss = self.tower(share_layer, mode, 'out_a') * id1
        b_loss = self.tower(share_layer, mode, 'out_b') * id2
        c_loss = self.tower(share_layer, mode, 'out_c') * id3

        return a_loss, b_loss, c_loss

    def tower(self, concat_vector, mode, name):
        with tf.compat.v1.variable_scope("deep_part_" + name):
            for units in [256, 128, 64]:
                concat_vector = tf.keras.layers.Dense(
                    units=units,
                    activation=self.activation,
                    kernel_initializer=self.kernel_initializer,
                    kernel_regularizer=self.regularizer,
                    bias_initializer=self.kernel_initializer,
                    bias_regularizer=None)(concat_vector)
                concat_vector = tf.compat.v1.layers.dropout(inputs=concat_vector, rate=0.0,
                                                            training=(mode == tf.estimator.ModeKeys.TRAIN))

        with tf.compat.v1.variable_scope("output_" + name):
            out = concat_vector
            output = tf.keras.layers.Dense(
                units=1,
                activation='sigmoid',
                kernel_initializer=self.kernel_initializer,
                kernel_regularizer=self.regularizer,
                bias_initializer=self.kernel_initializer,
                bias_regularizer=None)(out)

        return output

    def loss_function(self, y_hat_1, y_hat_2, y_hat_3, y_1, y_2, y_3):
        with tf.compat.v1.name_scope('card_1_loss'):
            card_1_loss = tf.compat.v1.losses.log_loss(labels=y_1, predictions=y_hat_1)
        with tf.compat.v1.name_scope('card_2_loss'):
            card_2_loss = tf.compat.v1.losses.log_loss(labels=y_2, predictions=y_hat_2)
        with tf.compat.v1.name_scope('wa_loss'):
            wa_loss = tf.compat.v1.losses.log_loss(labels=y_3, predictions=y_hat_3)

        return card_1_loss + card_2_loss + wa_loss

    def train_function(self, loss):
        with tf.compat.v1.name_scope('train_optimizer'):
            opt = tf.compat.v1.train.AdamOptimizer(self.learning_rate)
            grads = opt.compute_gradients(loss)
            train_op = opt.apply_gradients(grads, global_step=tf.compat.v1.train.get_global_step())

        return train_op
