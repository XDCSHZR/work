# -*- coding: utf-8 -*-
"""
Created on Fri Jun 21 17:50:00 2024

@author: jarretthan
"""

import tensorflow as tf

from layer.DCN import DCN
from layer.DNN import DNN
from layer.CGC import CGC
from layer.AIT import Attention, Info
from layer.Prediction import Prediction


class MFH_AITM_SF(object):
    def __init__(self, conf):
        self.model_conf = conf['model']
        self.train_conf = conf['train']
        self.seed = conf['seed']

    def inference(self,
                  numeric_cols, emb_cols,
                  emb_cols_sms, emb_cols_wa,
                  mode):
        with tf.device('/cpu:0'):
            ## input
            numeric_cols_tmp = tf.concat(numeric_cols, axis=-1)
            emb_no = tf.concat(emb_cols, axis=-1)
            emb_sms = tf.concat(emb_cols_sms, axis=-1)
            emb_wa = tf.concat(emb_cols_wa, axis=-1)

            # 连续型特征缺失值处理
            with tf.compat.v1.variable_scope(self.model_conf.input.name+'_no_process'):
                numeric_no = self.num_null_deal(numeric_cols_tmp)

            inputs_sb = tf.concat([numeric_no, emb_no, emb_sms, emb_wa], axis=-1)

            ## level 0，Share Bottom DCN
            with tf.compat.v1.variable_scope(self.model_conf.level_0.name):
                sb_dcn = DCN(self.model_conf.level_0.name,
                             self.model_conf.level_0.deep_layers_units,
                             self.model_conf.level_0.cross_layer_num,
                             activation=self.model_conf.level_0.deep_activation,
                             init_seed=self.seed,
                             reg_l2=self.model_conf.level_0.deep_regularizer_L2,
                             dropout_rate=self.model_conf.level_0.deep_dropout_rate,
                             use_bn=self.model_conf.level_0.deep_use_bn)
                level_0_outputs = sb_dcn.build_call(inputs_sb, mode)
                level_0_outputs = [level_0_outputs for _ in range(self.model_conf.level_0.num_tasks)]  # [渠道, 行为链路], [2]

                level_0_outputs[0] = tf.concat([level_0_outputs[0], emb_sms, emb_wa], axis=-1)  # sms, wa

            ## level 1, MLP + Switcher(CGC)
            level_1 = []  # [渠道[MLP, Switcher], 行为链路[MLP, Switcher]], [[2]*2]
            level_1_task_num = []  # [3,4]
            with tf.compat.v1.variable_scope(self.model_conf.level_1.name):
                conf_tmp_1 = [x for x in self.model_conf.level_1.items() if x[0] not in ['name']]
                for _, v in conf_tmp_1:
                    level_1_tmp = [
                        # MLP
                        DNN(v.MLP.name,
                            v.MLP.layers_units,
                            activation=v.MLP.activation,
                            init_seed=self.seed,
                            reg_l2=v.MLP.regularizer_L2,
                            dropout_rate=v.MLP.dropout_rate,
                            use_bn=v.MLP.use_bn),
                        # Switcher
                        CGC(v.Switcher.name,
                            v.Switcher.specific_expert_nums,
                            v.Switcher.specific_expert_layers_units,
                            v.Switcher.share_expert_nums,
                            v.Switcher.share_expert_layers_units,
                            v.Switcher.num_tasks,
                            activation=v.Switcher.activation,
                            init_seed=self.seed,
                            reg_l2=v.Switcher.regularizer_L2,
                            dropout_rate=v.Switcher.dropout_rate,
                            use_bn=v.Switcher.use_bn)
                    ]
                    level_1.append(level_1_tmp)
                    level_1_task_num.append(v.Switcher.num_tasks)

                level_1_outputs = [
                    level_1[i][1].build_call(  # Switcher
                        level_1[i][0].build_call(level_0_outputs[i], mode), mode)  # MLP
                    for i in range(self.model_conf.level_0.num_tasks)  # 渠道, 行为链路
                ]  # [渠道[card 1.0, card 2.0, wa], 行为链路[曝光, 注册, 发起授信, 提交授信]], [[3],[4]]
                level_1_outputs_ = []  # [card 1.0, card 2.0, wa, 曝光, 注册, 发起授信, 提交授信], [7]
                for x in level_1_outputs:
                    level_1_outputs_ += x

                level_1_outputs_[0] = tf.concat([level_1_outputs_[0], emb_sms], axis=-1)  # sms, card 1.0
                level_1_outputs_[1] = tf.concat([level_1_outputs_[1], emb_sms], axis=-1)  # sms, card 2.0
                level_1_outputs_[2] = tf.concat([level_1_outputs_[2], emb_wa], axis=-1)  # wa

            ## level 2, MLP + Switcher(CGC)
            level_2 = []  # [card 1.0[MLP, Switcher], card 2.0[2], wa[2], 曝光[2], 注册[2], 发起授信[2], 提交授信[2]], [[2]*7]
            level_2_task_num = []  # [4,4,4,3,3,3,3]
            with tf.compat.v1.variable_scope(self.model_conf.level_2.name):
                conf_tmp_2 = [x for x in self.model_conf.level_2.items() if x[0] not in ['name']]
                for _, v in conf_tmp_2:
                    level_2_tmp = [
                        # MLP
                        DNN(v.MLP.name,
                            v.MLP.layers_units,
                            activation=v.MLP.activation,
                            init_seed=self.seed,
                            reg_l2=v.MLP.regularizer_L2,
                            dropout_rate=v.MLP.dropout_rate,
                            use_bn=v.MLP.use_bn),
                        # Switcher
                        CGC(v.Switcher.name,
                            v.Switcher.specific_expert_nums,
                            v.Switcher.specific_expert_layers_units,
                            v.Switcher.share_expert_nums,
                            v.Switcher.share_expert_layers_units,
                            v.Switcher.num_tasks,
                            activation=v.Switcher.activation,
                            init_seed=self.seed,
                            reg_l2=v.Switcher.regularizer_L2,
                            dropout_rate=v.Switcher.dropout_rate,
                            use_bn=v.Switcher.use_bn)
                    ]
                    level_2.append(level_2_tmp)
                    level_2_task_num.append(v.Switcher.num_tasks)

                level_2_outputs = [
                    level_2[i][1].build_call(  # Switcher
                        level_2[i][0].build_call(level_1_outputs_[i], mode), mode)  # MLP
                    for i in range(sum(level_1_task_num))
                ]  # [card 1.0[曝光,注册,发起授信,提交授信], card 2.0[4], wa[4], 曝光[3], 注册[3], 发起授信[3], 提交授信[3]], [[4],[4],[4],[3],[3],[3],[3]]

            ## tower, MLP+AIT
            # tower input, 需要根据模型结构调整
            tower_inputs_0 = level_2_outputs[0] + level_2_outputs[1] + level_2_outputs[2]  # [card 1.0（曝光）,card 1.0（注册）,card 1.0（发起授信）,card 1.0（提交授信）,card 2.0（曝光）,...], [12]
            tower_inputs_1 = [
                [level_2_outputs[3:][j][i] for j in range(len(level_2_task_num[3:]))]
                for i in range(level_2_task_num[3:][0])
            ]  # [[曝光（card 1.0）,注册（card 1.0）,发起授信（card 1.0）,提交授信（card 1.0）],[曝光（card 2.0）...],[.]], [[4],[4],[4]]
            tower_inputs_1_ = []  # [曝光（card 1.0）,注册（card 1.0）,发起授信（card 1.0）,提交授信（card 1.0）,曝光（card 2.0）,...], [12]
            for x in tower_inputs_1:
                tower_inputs_1_ += x

            # tower_inputs_2 = [[emb_sms] for _ in range(level_1_task_num[-1])] + \
            #                  [[emb_sms] for _ in range(level_1_task_num[-1])] + \
            #                  [[emb_wa] for _ in range(level_1_task_num[-1])]

            # tower base AIT head
            with tf.compat.v1.variable_scope(self.model_conf.Tower.name):
                tower_num = sum(level_2_task_num) // self.model_conf.level_0.num_tasks  # 12
                link_num = tower_num // level_1_task_num[-1]  # 12//4=3, 需要根据模型结构调整
                info_num = tower_num - link_num  # 12-3=9
                ait_num = tower_num - link_num  # 12-3=9
                ait_link_num = ait_num // link_num  # 9//3=3

                # tower base
                tower_base = [
                    DNN(self.model_conf.Tower.base.name+'_{}'.format(i),
                        self.model_conf.Tower.base.layers_units,
                        activation=self.model_conf.Tower.base.activation,
                        init_seed=self.seed,
                        reg_l2=self.model_conf.Tower.base.regularizer_L2,
                        dropout_rate=self.model_conf.Tower.base.dropout_rate,
                        use_bn=self.model_conf.Tower.base.use_bn)
                    for i in range(tower_num)
                ]  # [card 1.0+曝光,card 1.0+注册,card 1.0+发起授信,card 1.0+提交授信,card 2.0+曝光,.], [12]
                tower_base_outputs = [
                    tower_base[i].build_call(
                        # tf.concat([tower_inputs_0[i]+tower_inputs_1_[i]]+tower_inputs_2[i], axis=-1),
                        tower_inputs_0[i] + tower_inputs_1_[i],
                        mode)
                    for i in range(tower_num)
                ]  # [12]
                tower_base_outputs = [
                    tower_base_outputs[(level_1_task_num[-1]*i):(level_1_task_num[-1]*(i+1))]
                    for i in range(link_num)
                ]  # [[4],[4],[4]]

                # tower AIT
                info = [
                    Info(self.model_conf.Tower.AIT.name+'_info_{}'.format(i),
                         self.model_conf.Tower.AIT.info_units,
                         activation=self.model_conf.Tower.AIT.info_activation,
                         init_seed=self.seed,
                         reg_l2=self.model_conf.Tower.AIT.info_regularizer_L2,
                         dropout_rate=self.model_conf.Tower.AIT.info_dropout_rate,
                         use_bn=self.model_conf.Tower.AIT.info_use_bn)
                    for i in range(info_num)
                ]  # [card 1.0+曝光->card 1.0+注册,card 1.0+注册->card 1.0+发起授信,card 1.0+发起授信->card 1.0+提交授信,card 2.0+曝光->card 2.0+注册,.], [9]
                ait = [
                    Attention(self.model_conf.Tower.AIT.name+'_ait_{}'.format(i),
                              self.model_conf.Tower.AIT.attention_units,
                              init_seed=self.seed,
                              reg_l2=self.model_conf.Tower.base.regularizer_L2)
                    for i in range(ait_num)
                ]  # [card 1.0+注册,card 1.0+发起授信,card 1.0+提交授信,card 2.0+注册,.], [9]

                ait_outputs = []  # [[4],[4],[4]]
                info_outputs = []  # [[3],[3],[3]]
                for i in range(link_num):
                    ait_outputs_tmp = [tower_base_outputs[i][0]]  # 每个链路的初始为tower base输出
                    info_outputs_tmp = []
                    for j in range(ait_link_num):
                        info_ = info[i*ait_link_num+j].build_call(ait_outputs_tmp[-1], mode)  # [batch_size,outputs_dim]
                        info_outputs_tmp.append(info_)
                        ait_ = ait[i*ait_link_num+j].build_call(
                            tf.concat([tf.expand_dims(info_outputs_tmp[-1], axis=1),
                                       tf.expand_dims(tower_base_outputs[i][j+1], axis=1)], axis=1)  # [batch_size,2,inputs_dim]
                        )  # [batch_size,outputs_dim]
                        ait_outputs_tmp.append(ait_)
                    ait_outputs.append(ait_outputs_tmp)
                    info_outputs.append(info_outputs_tmp)

                # tower head
                tower_head = [
                    Prediction(self.model_conf.Tower.head.name+'_{}'.format(i),
                               self.model_conf.Tower.head.layers_units,
                               activation=self.model_conf.Tower.head.activation,
                               init_seed=self.seed,
                               reg_l2=self.model_conf.Tower.head.regularizer_L2,
                               dropout_rate=self.model_conf.Tower.head.dropout_rate,
                               use_bn=self.model_conf.Tower.head.use_bn)
                    for i in range(tower_num)
                ]  # [12]
                tower_head_outputs = [
                    [
                        tower_head[i*level_1_task_num[-1]+j].build_call(ait_outputs[i][j], mode)
                        for j in range(level_1_task_num[-1])
                    ]
                    for i in range(link_num)
                ]  # [[4],[4],[4]]

        return tower_head_outputs

    def num_null_deal(self, numeric_tmp):
        """
        Args:
            numeric_tmp: default_value = -1

        Returns:
            numeric
        """

        with tf.compat.v1.variable_scope('numeric_miss_value'):
            miss_variable = tf.compat.v1.get_variable(shape=[1, numeric_tmp.get_shape()[-1]],
                                                      name='missing_var_numeric',
                                                      initializer=tf.compat.v1.glorot_normal_initializer(seed=self.seed),
                                                      regularizer=tf.keras.regularizers.l2(
                                                          l=self.model_conf.input.miss_numeric_regularizer_L2))

        flag = tf.less(numeric_tmp, 0)
        flag = tf.cast(flag, tf.float32)

        numeric = tf.multiply(flag, miss_variable) + tf.multiply((1 - flag), numeric_tmp)

        return numeric

    def loss_function(self, y_hat, y, id):
        """
        Args:
            y_hat: [3,4], [batch_size, 1]
            y: [3,4], [batch_size, 1]
            id: [3,], [batch_size, 1]

        Returns:
            loss_all(loss+loss_constraint), loss, loss_constraint, loss_last+loss_constraint, loss_list,
            loss_constraint_list, loss_all_uwl(loss_uwl+loss_constraint), loss_uwl
        """

        loss = []  # [[4],[4],[4]], [3,4]
        loss_constraint = []  # [[3],[3],[3]], [3,3]
        for i in range(len(self.train_conf.loss_weights)):  # 3
            with tf.compat.v1.name_scope('id_{}'.format(i)):  # card 1.0, card 2.0, wa
                loss_tmp = [
                    tf.compat.v1.losses.log_loss(y[i][j], y_hat[i][j], reduction='none')  # [batch_size,1]
                    for j in range(len(self.train_conf.loss_weights[i]))
                ]  # 4
                loss.append(loss_tmp)

                loss_constraint_tmp = [
                    tf.maximum(y_hat[i][j+1]-y_hat[i][j], 0)  # [batch_size,1]
                    for j in range(len(self.train_conf.loss_constraint_weights[i]))
                ]  # 3
                loss_constraint.append(loss_constraint_tmp)

        loss_sum = 0
        loss_constraint_sum = 0
        loss_last = 0  # loss label_credit_submit
        loss_list = []  # [[4],[4],[4]], [3,4]
        loss_list_nw = []  # [[4],[4],[4]], [3,4]
        loss_constraint_list = []  # [[3],[3],[3]], [3,3]
        for i in range(len(self.train_conf.loss_weights)):  # 3
            loss_list_tmp = []
            loss_list_tmp_nw = []
            for j in range(len(self.train_conf.loss_weights[i])):  # 4
                if self.train_conf.use_mask:
                    loss_tmp_nw = tf.reduce_mean(tf.multiply(loss[i][j], id[i]))
                    loss_tmp = self.train_conf.loss_weights[i][j] * loss_tmp_nw
                    loss_sum += loss_tmp
                    loss_list_tmp_nw.append(loss_tmp_nw)
                    loss_list_tmp.append(loss_tmp)
                else:
                    loss_tmp_nw = tf.reduce_mean(loss[i][j])
                    loss_tmp = self.train_conf.loss_weights[i][j] * loss_tmp_nw
                    loss_sum += loss_tmp
                    loss_list_tmp_nw.append(loss_tmp_nw)
                    loss_list_tmp.append(loss_tmp)
            loss_list_nw.append(loss_list_tmp_nw)
            loss_list.append(loss_list_tmp)

            loss_constraint_list_tmp = []
            for j in range(len(self.train_conf.loss_constraint_weights[i])):  # 3
                if self.train_conf.use_mask:
                    loss_constraint_tmp = self.train_conf.loss_constraint_weights[i][j] * \
                                          tf.reduce_mean(tf.multiply(loss_constraint[i][j], id[i]))
                    loss_constraint_sum += loss_constraint_tmp
                    loss_constraint_list_tmp.append(loss_constraint_tmp)
                else:
                    loss_constraint_tmp = self.train_conf.loss_constraint_weights[i][j] * \
                                          tf.reduce_mean(loss_constraint[i][j])
                    loss_constraint_sum += loss_constraint_tmp
                    loss_constraint_list_tmp.append(loss_constraint_tmp)
            loss_constraint_list.append(loss_constraint_list_tmp)

            if self.train_conf.use_mask:
                loss_last += self.train_conf.loss_weights[i][-1] * \
                             tf.reduce_mean(tf.multiply(loss[i][-1], id[i]))
            else:
                loss_last += self.train_conf.loss_weights[i][-1] * tf.reduce_mean(loss[i][-1])

        loss_uwl = self.uwl(loss_list_nw)

        return loss_sum + loss_constraint_sum, loss_sum, loss_constraint_sum, loss_last + loss_constraint_sum, \
               loss_list, loss_constraint_list, loss_uwl + loss_constraint_sum, loss_uwl

    def loss_function_weight(self, y_hat, y, id, w):
        """
        Args:
            y_hat: [3,4], [batch_size, 1]
            y: [3,4], [batch_size, 1]
            id: [3,], [batch_size, 1]
            w: [batch_size, 1]

        Returns:
            loss_all(loss+loss_constraint), loss, loss_constraint, loss_last+loss_constraint, loss_list,
            loss_constraint_list, loss_all_uwl(loss_uwl+loss_constraint), loss_uwl
        """

        loss = []  # [[4],[4],[4]], [3,4]
        loss_constraint = []  # [[3],[3],[3]], [3,3]
        for i in range(len(self.train_conf.loss_weights)):  # 3
            with tf.compat.v1.name_scope('id_{}'.format(i)):  # card 1.0, card 2.0, wa
                loss_tmp = [
                    tf.compat.v1.losses.log_loss(y[i][j], y_hat[i][j], reduction='none')  # [batch_size,1]
                    for j in range(len(self.train_conf.loss_weights[i]))
                ]  # 4
                loss.append(loss_tmp)

                loss_constraint_tmp = [
                    tf.maximum(y_hat[i][j+1]-y_hat[i][j], 0)  # [batch_size,1]
                    for j in range(len(self.train_conf.loss_constraint_weights[i]))
                ]  # 3
                loss_constraint.append(loss_constraint_tmp)

        loss_sum = 0
        loss_constraint_sum = 0
        loss_last = 0  # loss label_credit_submit
        loss_list = []  # [[4],[4],[4]], [3,4]
        loss_list_nw = []  # [[4],[4],[4]], [3,4]
        loss_constraint_list = []  # [[3],[3],[3]], [3,3]
        for i in range(len(self.train_conf.loss_weights)):  # 3
            loss_list_tmp = []
            loss_list_tmp_nw = []
            for j in range(len(self.train_conf.loss_weights[i])):  # 4
                loss_tmp_sw = tf.multiply(loss[i][j], w)
                if self.train_conf.use_mask:
                    loss_tmp_nw = tf.reduce_mean(tf.multiply(loss_tmp_sw, id[i]))
                    loss_tmp = self.train_conf.loss_weights[i][j] * loss_tmp_nw
                    loss_sum += loss_tmp
                    loss_list_tmp_nw.append(loss_tmp_nw)
                    loss_list_tmp.append(loss_tmp)
                else:
                    loss_tmp_nw = tf.reduce_mean(loss_tmp_sw)
                    loss_tmp = self.train_conf.loss_weights[i][j] * loss_tmp_nw
                    loss_sum += loss_tmp
                    loss_list_tmp_nw.append(loss_tmp_nw)
                    loss_list_tmp.append(loss_tmp)
            loss_list_nw.append(loss_list_tmp_nw)
            loss_list.append(loss_list_tmp)

            loss_constraint_list_tmp = []
            for j in range(len(self.train_conf.loss_constraint_weights[i])):  # 3
                loss_constraint_tmp_sw = tf.multiply(loss_constraint[i][j], w)
                if self.train_conf.use_mask:
                    loss_constraint_tmp = self.train_conf.loss_constraint_weights[i][j] * \
                                          tf.reduce_mean(tf.multiply(loss_constraint_tmp_sw, id[i]))
                    loss_constraint_sum += loss_constraint_tmp
                    loss_constraint_list_tmp.append(loss_constraint_tmp)
                else:
                    loss_constraint_tmp = self.train_conf.loss_constraint_weights[i][j] * \
                                          tf.reduce_mean(loss_constraint_tmp_sw)
                    loss_constraint_sum += loss_constraint_tmp
                    loss_constraint_list_tmp.append(loss_constraint_tmp)
            loss_constraint_list.append(loss_constraint_list_tmp)

            if self.train_conf.use_mask:
                loss_last += self.train_conf.loss_weights[i][-1] * \
                             tf.reduce_mean(tf.multiply(tf.multiply(loss[i][-1], w), id[i]))
            else:
                loss_last += self.train_conf.loss_weights[i][-1] * tf.reduce_mean(tf.multiply(loss[i][-1], w))

        loss_uwl = self.uwl(loss_list_nw)

        return loss_sum + loss_constraint_sum, loss_sum, loss_constraint_sum, loss_last + loss_constraint_sum, \
               loss_list, loss_constraint_list, loss_uwl + loss_constraint_sum, loss_uwl

    def uwl(self, loss_list):
        """

        Args:
            loss_list: [[4],[4],[4]], [3,4]

        Returns:
            loss
        """
        with tf.compat.v1.variable_scope('uwl'):
            loss_weights = [
                [
                    tf.compat.v1.get_variable(
                        name='uwl_loss_weights_{}_{}'.format(i, j),
                        shape=[],
                        initializer=tf.initializers.random_uniform(minval=0.2, maxval=1, seed=self.seed))
                    for j in range(len(loss_list[i]))  # 4
                ]
                for i in range(len(loss_list))  # 3
            ]

        loss = 0
        for i in range(len(loss_list)):
            for j in range(len(loss_list[i])):
                loss_weights_i_j = tf.clip_by_value(loss_weights[i][j], clip_value_min=0, clip_value_max=1)
                loss += loss_list[i][j] * tf.exp(-loss_weights_i_j) + loss_weights_i_j

        return loss

    def train_function(self, loss):
        with tf.compat.v1.name_scope('train_optimizer'):
            leraning_rate = tf.compat.v1.train.piecewise_constant_decay(
                tf.compat.v1.train.get_global_step(), self.train_conf.lr_milestones_steps, self.train_conf.lr)
            opt = tf.compat.v1.train.AdamOptimizer(leraning_rate)

            grads = opt.compute_gradients(loss)
            train_op = opt.apply_gradients(grads, global_step=tf.compat.v1.train.get_global_step())

        return train_op, leraning_rate
